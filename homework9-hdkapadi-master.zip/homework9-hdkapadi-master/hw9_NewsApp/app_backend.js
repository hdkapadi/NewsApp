
var express = require('express');
var app = express();
const router = express.Router();
var cors = require('cors')
const fetch = require("node-fetch");
const axios = require('axios')
const googleTrends = require('google-trends-api');


app.use(cors())

//trending chart call
app.get('/chart', function(req,res){
  //console.log(req.query);
  var key = req.query.word;
  googleTrends.interestOverTime({keyword: key, startTime: new Date('2019-06-01')})
    .then(function(results){
    //console.log(results);
    res.send(results);
  })
    .catch(function(err){
      console.error(err);
  });
});

//home fragment
app.get('/home',function(req,res){
  var url = "https://content.guardianapis.com/search?order-by=newest&show-fields=starRating,headline,thumbnail,short-url&api-key=72fe3ad3-18c3-4f52-aa90-b0dc7b8a2a47";
  fetch(url)
  .then(res => res.json())
  .then(data => {
    res.send({data});
    })
    .catch(err => {
      res.redirect('/error');
  });
});

//tabs -WORLD
app.get('/world', function(req,res){
   var url = "https://content.guardianapis.com/world?api-key=72fe3ad3-18c3-4f52-aa90-b0dc7b8a2a47&show-blocks=all";
   fetch(url)
   .then(res => res.json())
   .then(data => {
      res.send({ data });
   })
   .catch(err => {
      res.redirect('/error');
   });
});

//tabs -BUSINESS
app.get('/business', function(req,res){
   var url = "https://content.guardianapis.com/business?api-key=72fe3ad3-18c3-4f52-aa90-b0dc7b8a2a47&show-blocks=all";
   fetch(url)
   .then(res => res.json())
   .then(data => {
      res.send({ data });
   })
   .catch(err => {
      res.redirect('/error');
   });
});

//tabs -POLITICS
app.get('/politics', function(req,res){
   var url = "https://content.guardianapis.com/politics?api-key=72fe3ad3-18c3-4f52-aa90-b0dc7b8a2a47&show-blocks=all";
   fetch(url)
   .then(res => res.json())
   .then(data => {
      res.send({ data });
   })
   .catch(err => {
      res.redirect('/error');
   });
});

//tabs -SPORTS
app.get('/sports', function(req,res){
   var url = "https://content.guardianapis.com/sport?api-key=72fe3ad3-18c3-4f52-aa90-b0dc7b8a2a47&show-blocks=all";
   fetch(url)
   .then(res => res.json())
   .then(data => {
      res.send({ data });
   })
   .catch(err => {
      res.redirect('/error');
   });
});

//tabs -TECHNOLOGY
app.get('/tech', function(req,res){
   var url = "https://content.guardianapis.com/technology?api-key=72fe3ad3-18c3-4f52-aa90-b0dc7b8a2a47&show-blocks=all";
   fetch(url)
   .then(res => res.json())
   .then(data => {
      res.send({ data });
   })
   .catch(err => {
      res.redirect('/error');
   });
});

//tabs -SCIENCE
app.get('/science', function(req,res){
   var url = "https://content.guardianapis.com/science?api-key=72fe3ad3-18c3-4f52-aa90-b0dc7b8a2a47&show-blocks=all";
   fetch(url)
   .then(res => res.json())
   .then(data => {
      res.send({ data });
   })
   .catch(err => {
      res.redirect('/error');
   });
});

//search
app.get('/search', function(req,res){
  var search_word = req.query.q
  console.log(search_word);
   var url = "https://content.guardianapis.com/search?q=" + search_word + "&api-key=72fe3ad3-18c3-4f52-aa90-b0dc7b8a2a47&show-blocks=all";
   fetch(url)
   .then(res => res.json())
   .then(data => {
      res.send({ data });
   })
   .catch(err => {
      res.redirect('/error');
   });
});


//detail card
app.get('/detail', function(req,res){
  var art_id = req.query.art_id
  console.log(art_id);
  var url = "https://content.guardianapis.com/" + art_id + "?api-key=aa35b363-743f-4485-a8a7-6b633aaf4544&show-blocks=all";
  fetch(url)
   .then(res => res.json())
   .then(data => {
      res.send({ data });
   })
   .catch(err => {
      res.redirect('/error');
   });
});



// Xxxxx---------xxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxx---------------------------------------------------------------



//------------------------------------------HW8 below this-----------------------------------------------

//home page (nytimes call)
app.get('/', function(req,res){
    var url = "https://api.nytimes.com/svc/topstories/v2/home.json?api-key=irDRG2j932G5NtECoCXU5QFEsyEVDYCp";
    fetch(url)
    .then(res => res.json())
    .then(data => {
       res.send({ data });
    })
    .catch(err => {
       res.redirect('/error');
    });
});

//home page (guardian call)
app.get('/gu', function(req,res){
    var url = "https://content.guardianapis.com/search?order-by=newest&show-%20fields=starRating,headline,thumbnail,short-url&api-key=72fe3ad3-18c3-4f52-aa90-b0dc7b8a2a47xw";
    
    fetch(url)
    .then(res => res.json())
    .then(data => {
       res.send({ data });
       //console.log(data.response.results);
    })
    .catch(err => {
       res.redirect('/error');
    });
});

//section - world (nytimes)
app.get('/worldny', function(req,res){
   var url = "https://api.nytimes.com/svc/topstories/v2/world.json?api-key=irDRG2j932G5NtECoCXU5QFEsyEVDYCp";
   fetch(url)
   .then(res => res.json())
   .then(data => {
      res.send({ data });
   })
   .catch(err => {
      res.redirect('/error');
   });
});

//section - world (guardian)


//section-business (nytimes)
app.get('/businessny', function(req,res){
   var url = "https://api.nytimes.com/svc/topstories/v2/business.json?api-key=irDRG2j932G5NtECoCXU5QFEsyEVDYCp";
   fetch(url)
   .then(res => res.json())
   .then(data => {
      res.send({ data });
   })
   .catch(err => {
      res.redirect('/error');
   });
});

//section - business (guardian)


//section - politics (nytimes)
app.get('/politicsny', function(req,res){
   var url = "https://api.nytimes.com/svc/topstories/v2/politics.json?api-key=irDRG2j932G5NtECoCXU5QFEsyEVDYCp";
   fetch(url)
   .then(res => res.json())
   .then(data => {
      res.send({ data });
   })
   .catch(err => {
      res.redirect('/error');
   });
});

//section - politics (guardian)


//section - sports (nytimes)
app.get('/sportsny', function(req,res){
   var url = "https://api.nytimes.com/svc/topstories/v2/sports.json?api-key=irDRG2j932G5NtECoCXU5QFEsyEVDYCp";
   fetch(url)
   .then(res => res.json())
   .then(data => {
      res.send({ data });
   })
   .catch(err => {
      res.redirect('/error');
   });
});

//section - sports (guardian)


//section - technology (nytimes)
app.get('/techny', function(req,res){
   var url = "https://api.nytimes.com/svc/topstories/v2/technology.json?api-key=irDRG2j932G5NtECoCXU5QFEsyEVDYCp";
   fetch(url)
   .then(res => res.json())
   .then(data => {
      res.send({ data });
   })
   .catch(err => {
      res.redirect('/error');
   });
});

//section - technology (guardian)

//------------------------------------------------------------------------------------------

//expandcard (guardian)
app.get('/expandcard', function(req,res){
   const requery = req.query.article;
   //console.log(requery);
   const url = "http://content.guardianapis.com/" + requery + "api-key=72fe3ad3-18c3-4f52-aa90-b0dc7b8a2a47&show-blocks=all";
   fetch(url)
   .then(res => res.json())
   .then(data => {
      res.send({ data });
   })
   .catch(err => {
      res.redirect('/error');
   });
});

//expandcard (nytimes)
app.get('/expandcardny',function(req,res){
   const requery1 = req.query.id;
   //console.log(requery1);
   const url = 'https://api.nytimes.com/svc/search/v2/articlesearch.json?fq=web_url:("' + requery1 + '")&api-key=irDRG2j932G5NtECoCXU5QFEsyEVDYCp';
   fetch(url)
   .then(res => res.json())
   .then(data => {
      res.send({data});
   })
   .catch(err => {
      res.redirect('/error');
   });
});

//search (guardian)
app.get('/search',function(req,res){
   //console.log("searching");
   var url ="";
   if(req.query.gu){
      url = "https://content.guardianapis.com/search?q=" +req.query.gu+ "&api-key=72fe3ad3-18c3-4f52-aa90-b0dc7b8a2a47&show-blocks=all";
      //console.log(req.query.gu);
   }
   else{
      url = "https://api.nytimes.com/svc/search/v2/articlesearch.json?q=" + req.query.ny + "&api-key=irDRG2j932G5NtECoCXU5QFEsyEVDYCp";
      //console.log(req.query.ny); 
   }
   fetch(url)
   .then(res => res.json())
   .then(data => {
      res.send({data});
   })
   .catch(err => {
      res.redirect('/error');
   });
});

app.listen(8080, function () {
    // console.log('Example app listening on port 3000.');
});