package com.example.hw9;

import android.content.Context;
import android.graphics.Color;
import android.graphics.DashPathEffect;
import android.graphics.drawable.ColorDrawable;
import android.graphics.drawable.Drawable;
import android.os.Build;
import android.os.Bundle;

import androidx.annotation.RequiresApi;
import androidx.core.content.ContextCompat;
import androidx.fragment.app.Fragment;

import com.github.mikephil.charting.charts.LineChart;
import com.github.mikephil.charting.components.AxisBase;
import com.github.mikephil.charting.components.Legend;
import com.github.mikephil.charting.components.XAxis;
import com.github.mikephil.charting.components.YAxis;
import com.github.mikephil.charting.data.Entry;
import com.github.mikephil.charting.data.LineData;
import com.github.mikephil.charting.data.LineDataSet;
import com.github.mikephil.charting.formatter.IAxisValueFormatter;
import com.github.mikephil.charting.formatter.IValueFormatter;

import java.util.ArrayList;

import android.os.Handler;
import android.util.Log;
import android.view.KeyEvent;
import android.view.LayoutInflater;
import android.view.View;
import android.view.ViewGroup;
import android.view.inputmethod.EditorInfo;
import android.view.inputmethod.InputMethodManager;
import android.widget.EditText;
import android.widget.TextView;
import android.widget.Toast;

import com.android.volley.Request;
import com.android.volley.RequestQueue;
import com.android.volley.Response;
import com.android.volley.VolleyError;
import com.android.volley.toolbox.JsonObjectRequest;
import com.android.volley.toolbox.StringRequest;
import com.android.volley.toolbox.Volley;
import com.github.mikephil.charting.interfaces.datasets.ILineDataSet;
import com.github.mikephil.charting.utils.Utils;
import com.github.mikephil.charting.utils.ViewPortHandler;

import org.json.JSONArray;
import org.json.JSONException;
import org.json.JSONObject;

import java.time.LocalDateTime;
import java.time.ZoneId;
import java.time.ZonedDateTime;


/**
 * A simple {@link Fragment} subclass.
 */
public class TrendingFragment extends Fragment {
    private LineChart chart;
    private ArrayList<Entry> entries;
    private boolean dataReceived;
    String edit_text = "Coronavirus";

    public TrendingFragment() {
        // Required empty public constructor
    }



    @Override
    public View onCreateView(LayoutInflater inflater, ViewGroup container,
                             Bundle savedInstanceState) {
        // Inflate the layout for this fragment
        dataReceived = false;
        volleyCall(edit_text);
        View view = inflater.inflate(R.layout.fragment_trending, container, false);
        chart = view.findViewById(R.id.chart);
        final EditText edittext =  view.findViewById(R.id.edittext);
        edittext.setOnEditorActionListener(new TextView.OnEditorActionListener() {
            @Override
            public boolean onEditorAction(TextView v, int actionId, KeyEvent event) {
                if (actionId == EditorInfo.IME_ACTION_SEND || event.getAction() == KeyEvent.ACTION_DOWN){
                    boolean status  = false;
                    if (actionId == EditorInfo.IME_ACTION_SEND) {
                        //updateData();
                        edit_text = edittext.getText().toString();
                        updateData(edit_text);
                        volleyCall(edit_text);
                        status = true;
                    }
//                    return status;
                }
                return true;
            }
        });

        chart.setTouchEnabled(true);
        chart.setPinchZoom(true);
        return view;
    }

    private void updateData(String legendText){
        LineDataSet dataSet = new LineDataSet(entries, "Trending chart for " + legendText);
        dataSet.setColor(Color.parseColor("#6200EE"));
        dataSet.setValueTextColor(Color.parseColor("#6200EE"));
        dataSet.setCircleColor(Color.parseColor("#6200EE"));
        LineData lineData = new LineData(dataSet);
        lineData.setValueTextColor(Color.parseColor("#6200EE"));
        chart.setData(lineData);
        chart.getXAxis().setDrawGridLines(false);
        chart.setDrawGridBackground(false);
        chart.setBackgroundColor(Color.WHITE);
        chart.getAxisLeft().setDrawGridLines(false);
        chart.getAxisRight().setDrawGridLines(false);
        chart.invalidate(); // refresh
        chart.getLegend().setTextColor(Color.rgb(0,0,0));
        chart.getLegend().setTextSize((float) 13.5);
    }

    private void volleyCall(final String keyword){
        entries = new ArrayList<Entry>();
        RequestQueue queue = Volley.newRequestQueue(getActivity().getApplicationContext());
        String url ="https://hw9-backend-276422.wl.r.appspot.com/chart?word="+keyword;
        JsonObjectRequest request = new JsonObjectRequest(Request.Method.GET, url, null,
                new Response.Listener<JSONObject>() {
                    @RequiresApi(api = Build.VERSION_CODES.O)
                    @Override
                    public void onResponse(JSONObject response) {
                        try {
                            JSONObject res = response.getJSONObject("default");
                            dataReceived = true;
                            JSONArray arr = res.getJSONArray("timelineData");
                            for(int i = 0;i<arr.length();i++)
                            {
                                JSONObject hit = arr.getJSONObject(i);
                                JSONArray j = hit.getJSONArray("value");
                                Integer int1 = j.getInt(0);
                                entries.add(new Entry(i,  int1));
                            }
                            updateData(keyword);
                        }
                        catch (JSONException e) {
                            e.printStackTrace();
                        }
                    }
                }, new Response.ErrorListener() {
            @Override
            public void onErrorResponse(VolleyError error) {
                error.printStackTrace();
            }
        });
        queue.add(request);
    }

}

