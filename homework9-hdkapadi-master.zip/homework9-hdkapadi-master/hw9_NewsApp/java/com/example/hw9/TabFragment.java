package com.example.hw9;

import android.app.Dialog;
import android.content.Intent;
import android.content.SharedPreferences;
import android.os.Build;
import android.os.Bundle;

import androidx.annotation.RequiresApi;
import androidx.fragment.app.Fragment;
import androidx.recyclerview.widget.LinearLayoutManager;
import androidx.recyclerview.widget.RecyclerView;
import androidx.swiperefreshlayout.widget.SwipeRefreshLayout;

import android.os.Handler;
import android.util.Log;
import android.view.LayoutInflater;
import android.view.View;
import android.view.ViewGroup;
import android.widget.ImageView;
import android.widget.ProgressBar;
import android.widget.TextView;
import android.widget.Toast;


import com.android.volley.Request;
import com.android.volley.RequestQueue;
import com.android.volley.Response;
import com.android.volley.VolleyError;
import com.android.volley.toolbox.JsonObjectRequest;
import com.android.volley.toolbox.Volley;
import com.squareup.picasso.Picasso;

import org.json.JSONArray;
import org.json.JSONException;
import org.json.JSONObject;

import java.text.ParseException;
import java.text.SimpleDateFormat;
import java.util.ArrayList;
import java.util.Date;
import java.util.concurrent.TimeUnit;


/**
 * A simple {@link Fragment} subclass.
 */
public class TabFragment extends Fragment implements ExampleAdapter.OnItemClickListener,ExampleAdapter.OnItemLongClickListener{
    public static final String EXTRA_URL = "imageUrl";
    public static final String EXTRA_CREATOR = "creatorName";
    public static final String EXTRA_LIKES = "likeCount";
    public static final String EXTRA = "sect";
    public static final String ID = "id";
    public static final String DETAIL = "detail_date";
    public final String MyBook = "bookmarks";
    private SwipeRefreshLayout mSwipeRefreshLayout;
    int pos;

    private boolean dataReceived;
    private ExampleAdapter mExampleAdapter;
    private ViewPagerAdapter viewPagerAdapter;
    private RecyclerView mRecyclerView;
    private ArrayList<ExampleItem> mExampleList;
    private RequestQueue mRequestQueue;
    private JSONObject res;
    private ProgressBar spinner;

    public static Fragment getInstance(int position) {
        Bundle bundle = new Bundle();
        bundle.putInt("pos", position);
        TabFragment tabFragment = new TabFragment();
        tabFragment.setArguments(bundle);
        return tabFragment;
    }

    public TabFragment() {
        // Required empty public constructor
    }

    @Override
    public View onCreateView(LayoutInflater inflater, ViewGroup container,
                             Bundle savedInstanceState) {

        super.onCreate(savedInstanceState);
        final View view = inflater.inflate(R.layout.fragment_tab, container, false);
        spinner = (ProgressBar)view.findViewById(R.id.progressBar2);
        mSwipeRefreshLayout = view.findViewById(R.id.swipe_tab);
        dataReceived = false;
        mRecyclerView = view.findViewById(R.id.recyclerviewtabs);
        LinearLayoutManager mgr = new LinearLayoutManager(getContext());
        mRecyclerView.setHasFixedSize(true);
        mRecyclerView.setLayoutManager(mgr);
        pos = getArguments().getInt("pos");

        mExampleList = new ArrayList<>();

        mRequestQueue = Volley.newRequestQueue(getContext());
        dataReceived = false;
        parseJSON();
        mRecyclerView.setVisibility(View.GONE);
        final Handler handler = new Handler();
        Runnable runnable = new Runnable() {
            @Override
            public void run() {
                if(dataReceived) {
                    try {
                        spinner.setVisibility(View.GONE);
                        TextView textView2 = view.findViewById(R.id.progress_text);
                        textView2.setVisibility(View.GONE);
                        mRecyclerView.setVisibility(View.VISIBLE);
                        displayData();
                    } catch (JSONException e) {
                        e.printStackTrace();
                    }
                }
                else {
                    handler.postDelayed(this, 1000);
                }
            }
        };
        handler.post(runnable);

        mSwipeRefreshLayout.setOnRefreshListener(new SwipeRefreshLayout.OnRefreshListener() {
            @RequiresApi(api = Build.VERSION_CODES.O)
            @Override
            public void onRefresh() {
                dataReceived = false;
                parseJSON();
                dataReceived = true;
                Log.i("called","refresh Dta called 1"+dataReceived);
                final Handler handler = new Handler();
                handler.postDelayed(new Runnable() {
                    @Override
                    public void run() {
                        if (dataReceived){
                            Log.i("called","refresh Dta called 2");
                            try {
                                displayData();
                                Log.i("called","refresh Dta called 3");
                            } catch (JSONException e) {
                                e.printStackTrace();
                            }
                        }
                        if(mSwipeRefreshLayout.isRefreshing()) {
                            mSwipeRefreshLayout.setRefreshing(false);
                        }
                    }
                }, 1000);
            }
        });

        return view;
    }

    private void displayData() throws JSONException {
//        Log.i("displayData","methodcalled****");
        JSONArray jsonArray = res.getJSONArray("results");
        for (int i = 0; i < jsonArray.length(); i++) {
            String imageUrl="";
            JSONObject hit = jsonArray.getJSONObject(i);
            JSONObject img = hit.getJSONObject("blocks");
            try
            {
                JSONObject img1 = img.getJSONObject("main");
                JSONArray arr = img1.getJSONArray("elements");
                JSONObject obj = arr.getJSONObject(0);
                JSONArray arr1 = obj.getJSONArray("assets");
                JSONObject obj1 = arr1.getJSONObject(0);
                imageUrl = obj1.getString("file");

            }
            catch (JSONException e){
                imageUrl = "https://assets.guim.co.uk/images/eada8aa27c12fe2d5afa3a89d3fbae0d/fallback-logo.png";
            }

            String art_id = hit.getString("id");
            String web_url = hit.getString("webUrl");
            String title = hit.getString("webTitle");
            String date = hit.getString("webPublicationDate");
            String name = hit.getString("sectionName");

            mExampleList.add(new ExampleItem(imageUrl, title, date, name, art_id,web_url));
        }
        mExampleAdapter = new ExampleAdapter(getActivity(), mExampleList);
        mRecyclerView.setAdapter(mExampleAdapter);
        mExampleAdapter.notifyDataSetChanged();
        mExampleAdapter.setOnItemClickListener(TabFragment.this);
        mExampleAdapter.setOnItemLongClickListener(TabFragment.this);
    }

    private void parseJSON() {
//        Log.i("CALLED*******","parsonJSON called_------"+pos);
        String url = "";
        final SimpleDateFormat sdf = new SimpleDateFormat();
        if (pos == 0) {
//            Log.i("CALLED*******","world"+pos);
            url = "https://hw9-backend-276422.wl.r.appspot.com//world";
        }
        else if (pos == 1){
//            Log.i("CALLED*******","bus"+pos);
            url = "https://hw9-backend-276422.wl.r.appspot.com/business";
        }
        else if (pos == 2){
//            Log.i("CALLED*******","pol"+pos);
            url = "https://hw9-backend-276422.wl.r.appspot.com/politics";
        }
        else if (pos == 3){
//            Log.i("CALLED*******","sport"+pos);
            url = "https://hw9-backend-276422.wl.r.appspot.com/sports";
        }
        else if (pos == 4){
//            Log.i("CALLED*******","tech"+pos);
            url = "https://hw9-backend-276422.wl.r.appspot.com/tech";
        }
        else if (pos == 5){
//            Log.i("CALLED*******","sci"+pos);
            url = "https://hw9-backend-276422.wl.r.appspot.com/science";
        }
        JsonObjectRequest request = new JsonObjectRequest(Request.Method.GET, url, null,
                new Response.Listener<JSONObject>() {
                    @RequiresApi(api = Build.VERSION_CODES.O)
                    @Override
                    public void onResponse(JSONObject response) {
                        try {
//                            Log.i("insideTRy","TAb fragment parseJSON");
                            res = response.getJSONObject("data").getJSONObject("response");
                            dataReceived = true;
                        } catch (JSONException e) {
                            e.printStackTrace();
                        }
                    }
                }, new Response.ErrorListener() {
            @Override
            public void onErrorResponse(VolleyError error) {
                error.printStackTrace();
            }
        });
        mRequestQueue.add(request);
    }

    public void onItemClick(int position) {
        Intent detailIntent = new Intent(getActivity(), DetailActivity.class);
        ExampleItem clickedItem = mExampleList.get(position);

        detailIntent.putExtra(EXTRA_URL, clickedItem.getImageUrl());
        detailIntent.putExtra(EXTRA_CREATOR, clickedItem.getCreator());

        detailIntent.putExtra(EXTRA_LIKES, clickedItem.getLikeCount());
        detailIntent.putExtra(EXTRA,clickedItem.getSection());
        detailIntent.putExtra(ID,clickedItem.getid());

        startActivity(detailIntent);
    }
    @Override
    public void onItemLongClick(int p) {
        final JSONObject obj = new JSONObject();
        SharedPreferences sharedPreferences = getContext().getSharedPreferences(MyBook,0);
        final SharedPreferences.Editor editor = sharedPreferences.edit();
        ExampleItem item = mExampleList.get(p);
        final Dialog dialog = new Dialog(getContext());
        dialog.setContentView(R.layout.dialog);

        final String articleId = item.getid();
        final String title = item.getCreator();
        String date = item.getLikeCount();
        String section = item.getSection();
        String imageUrl = item.getImageUrl();

        try {
            obj.put("imageUrl",imageUrl);
            obj.put("title",title);
            obj.put("date",date);
            obj.put("section",section);
        } catch (JSONException e) {
            e.printStackTrace();
        }

        ImageView imageView = dialog.findViewById(R.id.dialog_image);
        Picasso.with(getContext()).load(imageUrl).into(imageView);
        TextView textView = dialog.findViewById(R.id.dialog_text);
        textView.setText(item.getCreator());
        ImageView imageView1 = dialog.findViewById(R.id.dialog_twitter);
        imageView1.setImageResource(R.drawable.bluetwitter);
        final ImageView imageView2 = dialog.findViewById(R.id.dialog_bookmark);
        final ImageView imageView3 = dialog.findViewById(R.id.dialog_bookmark1);

        if (sharedPreferences.contains(articleId)){
            imageView2.setVisibility(View.GONE);
            imageView3.setVisibility(View.VISIBLE);
            imageView3.setOnClickListener(new View.OnClickListener() {
                @Override
                public void onClick(View v) {
                    imageView2.setVisibility(View.VISIBLE);
                    imageView3.setVisibility(View.GONE);
                    editor.remove(articleId);
                    editor.apply();
                    Toast.makeText(getContext(), "\""+title+"\" was removed from bookmarks", Toast.LENGTH_SHORT).show();
                    mExampleAdapter.notifyDataSetChanged();
                }
            });
        }
        else {
            imageView2.setVisibility(View.VISIBLE);
            imageView3.setVisibility(View.GONE);
            imageView2.setOnClickListener(new View.OnClickListener() {
                @Override
                public void onClick(View v) {
                    imageView2.setVisibility(View.GONE);
                    imageView3.setVisibility(View.VISIBLE);
                    editor.putString(articleId,obj.toString());
                    editor.apply();
                    Toast.makeText(getContext(), "\""+title+"\" was added to bookmarks", Toast.LENGTH_SHORT).show();
                    mExampleAdapter.notifyDataSetChanged();
                }
            });
        }

        //add to bookmark
        imageView2.setOnClickListener(new View.OnClickListener() {
            @Override
            public void onClick(View v) {
                imageView2.setVisibility(View.GONE);
                imageView3.setVisibility(View.VISIBLE);
                editor.putString(articleId,obj.toString());
                editor.apply();
                Toast.makeText(getContext(), "\""+title+"\" was added to bookmarks", Toast.LENGTH_SHORT).show();
                mExampleAdapter.notifyDataSetChanged();
            }
        });

        //remove from bookmark
        imageView3.setOnClickListener(new View.OnClickListener() {
            @Override
            public void onClick(View v) {
                imageView2.setVisibility(View.VISIBLE);
                imageView3.setVisibility(View.GONE);
                editor.remove(articleId);
                editor.apply();
                Toast.makeText(getContext(), "\""+title+"\" was removed from bookmarks", Toast.LENGTH_SHORT).show();
                mExampleAdapter.notifyDataSetChanged();
            }
        });
        dialog.show();
    }

    @Override
    public void onResume() {
        super.onResume();
        if(mExampleAdapter != null)
            mExampleAdapter.notifyDataSetChanged();
    }
}





