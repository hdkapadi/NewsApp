package com.example.hw9;

import android.app.Dialog;
import android.content.Context;
import android.content.Intent;
import android.content.SharedPreferences;
import android.graphics.drawable.Drawable;
import android.location.Address;
import android.location.Geocoder;
import android.net.Uri;
import android.os.Build;
import android.os.Bundle;
import android.Manifest;

import androidx.annotation.RequiresApi;
import androidx.cardview.widget.CardView;
import androidx.fragment.app.Fragment;
import androidx.recyclerview.widget.LinearLayoutManager;
import androidx.recyclerview.widget.RecyclerView;
import androidx.swiperefreshlayout.widget.SwipeRefreshLayout;

import android.os.Handler;
import android.util.Log;
import android.view.LayoutInflater;
import android.view.View;
import android.view.ViewGroup;
import android.widget.FrameLayout;
import android.widget.ImageView;
import android.widget.ProgressBar;
import android.widget.TextView;
import android.widget.Toast;


import com.android.volley.Request;
import com.android.volley.RequestQueue;
import com.android.volley.Response;
import com.android.volley.VolleyError;
import com.android.volley.toolbox.JsonObjectRequest;
import com.android.volley.toolbox.StringRequest;
import com.android.volley.toolbox.Volley;
import com.squareup.picasso.Picasso;

import org.json.JSONArray;
import org.json.JSONException;
import org.json.JSONObject;
import org.w3c.dom.Text;

import java.io.IOException;
import java.net.URLEncoder;
import java.text.DateFormat;
import java.text.ParseException;
import java.text.SimpleDateFormat;
import java.time.LocalDateTime;
import java.time.ZoneId;
import java.time.ZonedDateTime;
import java.time.temporal.ChronoUnit;
import java.util.ArrayList;
import java.util.Date;
import java.util.HashMap;
import java.util.List;

import java.util.Locale;
import java.util.Map;
import java.util.concurrent.TimeUnit;

import static android.content.Context.MODE_PRIVATE;
import static java.util.Locale.*;



/**
 * A simple {@link Fragment} subclass.
 */
public class HomeFragment extends Fragment implements ExampleAdapter.OnItemClickListener,ExampleAdapter.OnItemLongClickListener{
    public static final String EXTRA_URL = "imageUrl";
    public static final String EXTRA_CREATOR = "creatorName";
    public static final String EXTRA_LIKES = "likeCount";
    public static final String EXTRA = "sect";
    public static final String ID = "id";
    public static final String DETAIL = "detail_date";
    public static final String EXTRA_WEBURL = "webUrl";
    public final String MyBook = "bookmarks";
    public static final String PRE = "Check out this link: ";
    
//    ChronoUnit
    private boolean dataReceived;
    private ExampleAdapter mExampleAdapter;
    private Context mContext;
    private RecyclerView mRecyclerView;
    private ArrayList<ExampleItem> mExampleList;
    private RequestQueue mRequestQueue;
    private ImageView bookmarkImageView;
    private SwipeRefreshLayout mSwipeRefreshLayout;
    private JSONObject res;
    private ProgressBar spinner;

    private FrameLayout frameLayout;
//    final SharedPreferences sharedPreferences = mContext.getSharedPreferences(MyBook,0);
//    final SharedPreferences.Editor editor = sharedPreferences.edit();

    public HomeFragment() {
        // Required empty public constructor
    }
    
    @Override
    public View onCreateView(LayoutInflater inflater, ViewGroup container,
                             Bundle savedInstanceState) {

        final HashMap<String,String> hm = new HashMap<>();
        hm.put("Clouds","https://csci571.com/hw/hw9/images/android/cloudy_weather.jpg");
        hm.put("Clear","https://csci571.com/hw/hw9/images/android/clear_weather.jpg");
        hm.put("Snow","https://csci571.com/hw/hw9/images/android/snowy_weather.jpg");
        hm.put("Rain","https://csci571.com/hw/hw9/images/android/rainy_weather.jpg");
        hm.put("Drizzle","https://csci571.com/hw/hw9/images/android/rainy_weather.jpg");
        hm.put("Rain/Drizzle","https://csci571.com/hw/hw9/images/android/rainy_weather.jpg");
        hm.put("Thunderstorm","https://csci571.com/hw/hw9/images/android/thunder_weather.jpg");
        hm.put("Sunny","https://csci571.com/hw/hw9/images/android/sunny_weather.jpg");

        double MyLat=34.0266;
        double MyLong=-118.283;
        SimpleDateFormat sdf = new SimpleDateFormat();
        super.onCreate(savedInstanceState);
        final View view = inflater.inflate(R.layout.fragment_home, container, false);;

        mSwipeRefreshLayout = view.findViewById(R.id.swipe);
        spinner = (ProgressBar)view.findViewById(R.id.progressBar1);

        final TextView textView =  view.findViewById(R.id.textView3);
        final TextView textView1 =  view.findViewById(R.id.textView7);

        // Inflate the layout for this fragment
        RequestQueue queue = Volley.newRequestQueue(getActivity().getApplicationContext());
        String url ="https://api.openweathermap.org/data/2.5/weather?q=los%20angeles&units=metric&appid=ae15dae7f6b2b37a8391303af9e7282c";

// Request a string response from the provided URL.
        StringRequest stringRequest = new StringRequest(Request.Method.GET, url,
                new Response.Listener<String>() {
                    @Override
                    public void onResponse(String response) {
                        // Display the first 500 characters of the response string.
                        try {
                            JSONObject results = new JSONObject(response);
                            String temp = results.getString("main");
                            JSONObject d = new JSONObject(temp);

                            textView.setText(Math.round(d.getDouble("temp"))+"°C");

                            JSONArray data = results.getJSONArray("weather");
                            JSONObject j  = data.getJSONObject(0);
                            String type = j.getString("main");
                            String imageUrl="";

                            if (hm.containsKey(type))
                            {
                                 imageUrl = hm.get(type);
                            }
                            else {
                                 imageUrl = hm.get("Sunny");
                             }

                            ImageView imgView = view.findViewById(R.id.imgView);
                            Picasso.with(getContext()).load(imageUrl).into(imgView);
                            textView1.setText(type);

                        } catch (JSONException e) {
                            e.printStackTrace();
                        }
                    }

//                    private void cardbg(String t) {
//                         String imageUrl="";
//                        if (t == "Clouds"){
//                            imageUrl = "https://csci571.com/hw/hw9/images/android/cloudy_weather.jpg";
//                        }
//                        else if (t == "Clear"){
//                            imageUrl = "https://csci571.com/hw/hw9/images/android/clear_weather.jpg";
//                        }
//                        else if (t == "Snow"){
//                            imageUrl = "https://csci571.com/hw/hw9/images/android/snowy_weather.jpg";
//                        }
//                        else if (t == "Rain/Drizzle"){
//                            imageUrl = "https://csci571.com/hw/hw9/images/android/rainy_weather.jpg";
//                        }
//                        else if (t == "Rain"){
//                            imageUrl = "https://csci571.com/hw/hw9/images/android/rainy_weather.jpg";
//                        }
//                        else if (t == "Drizzle"){
//                            imageUrl = "https://csci571.com/hw/hw9/images/android/rainy_weather.jpg";
//                        }
//                        else if (t == "Thunderstorm"){
//                            imageUrl = "https://csci571.com/hw/hw9/images/android/thunder_weather.jpg";
//                        }
//                        else {
//                            imageUrl = "https://csci571.com/hw/hw9/images/android/sunny_weather.jpg";
//                        }
//
//
//
//                    }
                }, new Response.ErrorListener() {
            @Override
            public void onErrorResponse(VolleyError error) {
            }
        });

// Add the request to the RequestQueue.
        queue.add(stringRequest);

        mRecyclerView = view.findViewById(R.id.recyclerview);
        LinearLayoutManager mgr = new LinearLayoutManager(getContext());
        mRecyclerView.setHasFixedSize(true);
        mRecyclerView.setLayoutManager(mgr);
        bookmarkImageView = view.findViewById(R.id.imageView);


        mExampleList = new ArrayList<>();

        mRequestQueue = Volley.newRequestQueue(getContext());
        dataReceived = false;
        parseJSON();
        mRecyclerView.setVisibility(View.GONE);
        final Handler handler = new Handler();
        Runnable runnable = new Runnable() {
            @RequiresApi(api = Build.VERSION_CODES.O)
            @Override
            public void run() {
                if(dataReceived) {
                    try {
                        spinner.setVisibility(View.GONE);
                        TextView textView2 = view.findViewById(R.id.progress_text);
                        textView2.setVisibility(View.GONE);
                        mRecyclerView.setVisibility(View.VISIBLE);
                        displayData();
                    } catch (JSONException e) {
                        e.printStackTrace();
                    }
                }
                else {
                    handler.postDelayed(this, 1000);
                }
            }
        };
        handler.post(runnable);

//        ----------------pull to refresh code -----------------

        mSwipeRefreshLayout.setOnRefreshListener(new SwipeRefreshLayout.OnRefreshListener() {
            @RequiresApi(api = Build.VERSION_CODES.O)
            @Override
            public void onRefresh() {
                dataReceived = false;
                parseJSON();
                final Handler handler = new Handler();
                handler.postDelayed(new Runnable() {
                    @Override
                    public void run() {
                        if (dataReceived){
                            try {
                                displayData();
                                mExampleAdapter.notifyDataSetChanged();
                            } catch (JSONException e) {
                                e.printStackTrace();
                            }
                        }
                        if(mSwipeRefreshLayout.isRefreshing()) {
                            mSwipeRefreshLayout.setRefreshing(false);
                        }
                    }
                }, 1000);
            }
        });

        return view;
    }

    @RequiresApi(api = Build.VERSION_CODES.O)
    private void displayData() throws JSONException{

        JSONArray jsonArray = res.getJSONArray("results");
        for (int i = 0; i < jsonArray.length(); i++) {
            JSONObject hit = jsonArray.getJSONObject(i);
            String art_id = hit.getString("id");
            String web_url = hit.getString("webUrl");
            JSONObject img = hit.getJSONObject("fields");
            String imageUrl="";
            final String title = hit.getString("webTitle");
            try {
               imageUrl = img.getString("thumbnail");
                if (imageUrl.length() == 0){
                    imageUrl = "https://assets.guim.co.uk/images/eada8aa27c12fe2d5afa3a89d3fbae0d/fallback-logo.png";
                }
            }
            catch (JSONException e){
                imageUrl = "https://assets.guim.co.uk/images/eada8aa27c12fe2d5afa3a89d3fbae0d/fallback-logo.png";
            }

            String date = hit.getString("webPublicationDate");

            String name = hit.getString("sectionName");

            final String url = imageUrl;

            mExampleList.add(new ExampleItem(imageUrl, title, date, name, art_id, web_url));
        }

        mExampleAdapter = new ExampleAdapter(getActivity(), mExampleList);
        mRecyclerView.setAdapter(mExampleAdapter);
        mExampleAdapter.notifyDataSetChanged();
        mExampleAdapter.setOnItemClickListener(HomeFragment.this);
        mExampleAdapter.setOnItemLongClickListener(HomeFragment.this);
    }

    private void parseJSON() {
//        String url = "https://content.guardianapis.com/search?order-by=newest&show-fields=starRating,headline,thumbnail,short-url&api-key=72fe3ad3-18c3-4f52-aa90-b0dc7b8a2a47";
        String url = "https://hw9-backend-276422.wl.r.appspot.com/home";
        JsonObjectRequest request = new JsonObjectRequest(Request.Method.GET, url, null,
                new Response.Listener<JSONObject>() {
                    @RequiresApi(api = Build.VERSION_CODES.O)
                    @Override
                    public void onResponse(JSONObject response) {
                        try {

                             res = response.getJSONObject("data").getJSONObject("response");
                             dataReceived=true;
                            //Log.i("tag",res.toString());

                        } catch (JSONException e) {
                            e.printStackTrace();
                            //Log.i("err",response.toString());
                        }
                    }
                }, new Response.ErrorListener() {
            @Override
            public void onErrorResponse(VolleyError error) {
                error.printStackTrace();
            }
        });

        mRequestQueue.add(request);

    }

    public void onItemClick(int position) {
        Intent detailIntent = new Intent(getActivity(), DetailActivity.class);
        ExampleItem clickedItem = mExampleList.get(position);

        detailIntent.putExtra(EXTRA_URL, clickedItem.getImageUrl());
        detailIntent.putExtra(EXTRA_CREATOR, clickedItem.getCreator());
        detailIntent.putExtra(EXTRA_LIKES, clickedItem.getLikeCount());
        detailIntent.putExtra(EXTRA,clickedItem.getSection());
        detailIntent.putExtra(ID,clickedItem.getid());
        detailIntent.putExtra(EXTRA_WEBURL,clickedItem.geturl());

        startActivity(detailIntent);
    }


    @Override
    public void onResume() {
        super.onResume();
        if(mExampleAdapter != null)
            mExampleAdapter.notifyDataSetChanged();
    }

    @Override
    public void onItemLongClick(int p) {
        final JSONObject obj = new JSONObject();
        SharedPreferences sharedPreferences = getContext().getSharedPreferences(MyBook,0);
        final SharedPreferences.Editor editor = sharedPreferences.edit();
        ExampleItem item = mExampleList.get(p);
        final Dialog dialog = new Dialog(getContext());
        dialog.setContentView(R.layout.dialog);

        final String articleId = item.getid();
        final String title = item.getCreator();
        String date = item.getLikeCount();
        String section = item.getSection();
        String imageUrl = item.getImageUrl();
        final String web_url = item.geturl();

        try {
            obj.put("imageUrl",imageUrl);
            obj.put("title",title);
            obj.put("date",date);
            obj.put("section",section);
            obj.put("web_url",web_url);
        } catch (JSONException e) {
            e.printStackTrace();
        }
        ImageView imageView = dialog.findViewById(R.id.dialog_image);
        Picasso.with(getContext()).load(imageUrl).into(imageView);
        TextView textView = dialog.findViewById(R.id.dialog_text);
        textView.setText(item.getCreator());
        ImageView imageView1 = dialog.findViewById(R.id.dialog_twitter);
        imageView1.setImageResource(R.drawable.twitter);
        final ImageView imageView2 = dialog.findViewById(R.id.dialog_bookmark);
        final ImageView imageView3 = dialog.findViewById(R.id.dialog_bookmark1);

        if (sharedPreferences.contains(articleId)){
            imageView2.setVisibility(View.GONE);
            imageView3.setVisibility(View.VISIBLE);
            imageView3.setOnClickListener(new View.OnClickListener() {
                @Override
                public void onClick(View v) {
                    imageView2.setVisibility(View.VISIBLE);
                    imageView3.setVisibility(View.GONE);
                    editor.remove(articleId);
                    editor.apply();
                    Toast.makeText(getContext(), "\""+title+"\" was removed from bookmarks", Toast.LENGTH_SHORT).show();
                    mExampleAdapter.notifyDataSetChanged();
                }
            });
        }
        else {
            imageView2.setVisibility(View.VISIBLE);
            imageView3.setVisibility(View.GONE);
            imageView2.setOnClickListener(new View.OnClickListener() {
                @Override
                public void onClick(View v) {
                    imageView2.setVisibility(View.GONE);
                    imageView3.setVisibility(View.VISIBLE);
                    editor.putString(articleId,obj.toString());
                    editor.apply();
                    Toast.makeText(getContext(), "\""+title+"\" was added to bookmarks", Toast.LENGTH_SHORT).show();
                    mExampleAdapter.notifyDataSetChanged();
                }
            });
        }

        //add to bookmark
        imageView2.setOnClickListener(new View.OnClickListener() {
            @Override
            public void onClick(View v) {
                imageView2.setVisibility(View.GONE);
                imageView3.setVisibility(View.VISIBLE);
                editor.putString(articleId,obj.toString());
                editor.apply();
                Toast.makeText(getContext(), "\""+title+"\" was added to bookmarks", Toast.LENGTH_SHORT).show();
                mExampleAdapter.notifyDataSetChanged();
            }
        });

        //remove from bookmark
        imageView3.setOnClickListener(new View.OnClickListener() {
            @Override
            public void onClick(View v) {
                imageView2.setVisibility(View.VISIBLE);
                imageView3.setVisibility(View.GONE);
                editor.remove(articleId);
                editor.apply();
                Toast.makeText(getContext(), "\""+title+"\" was removed from bookmarks", Toast.LENGTH_SHORT).show();
                mExampleAdapter.notifyDataSetChanged();
            }
        });

        imageView1.setOnClickListener(new View.OnClickListener() {
            @Override
            public void onClick(View v) {
                String url = "http://www.twitter.com/intent/tweet?text=Check%20out%20this%20Link:%20" +web_url+ "&hashtags=CSCI571NewsSearch";
                Intent i = new Intent(Intent.ACTION_VIEW);
//                i.putExtra(PRE,"");
                i.setData(Uri.parse(url));
                startActivity(i);
            }
        });

        dialog.show();
    }

//    public void share_twitter(View view) {
//        String tweetUrl = String.format("https://twitter.com/intent/tweet?text=%s&url=%s&hashtags=CSCI571NewsSearch",
//                urlEncode("Check out this Link: "),
//                urlEncode(Url));
//        Intent intent = new Intent(Intent.ACTION_VIEW, Uri.parse(tweetUrl));
//        this.startActivity(intent);
//    }
}





