package com.example.hw9;

import androidx.annotation.NonNull;
import androidx.appcompat.app.AlertDialog;
import androidx.appcompat.app.AppCompatActivity;
import androidx.appcompat.widget.SearchView;
import androidx.appcompat.widget.Toolbar;
import androidx.core.app.ActivityCompat;
import androidx.core.content.ContextCompat;
import androidx.core.view.MenuItemCompat;
import androidx.fragment.app.Fragment;
import androidx.fragment.app.FragmentTransaction;
import androidx.recyclerview.widget.RecyclerView;
import android.Manifest;
import android.annotation.SuppressLint;
import android.app.SearchManager;
import android.content.Context;
import android.content.DialogInterface;
import android.content.Intent;
import android.content.SharedPreferences;
import android.content.pm.PackageManager;
import android.content.res.ColorStateList;
import android.location.Address;
import android.location.Geocoder;
import android.location.Location;
import android.location.LocationListener;
import android.location.LocationManager;
import android.os.Bundle;
import android.util.Log;
import android.view.Menu;
import android.view.MenuInflater;
import android.view.MenuItem;
import android.view.View;
import android.widget.AdapterView;
import android.widget.ArrayAdapter;

import com.android.volley.Request;
import com.android.volley.RequestQueue;
import com.android.volley.Response;
import com.android.volley.VolleyError;
import com.android.volley.toolbox.JsonObjectRequest;
import com.android.volley.toolbox.Volley;
import com.google.android.material.bottomnavigation.BottomNavigationItemView;
import com.google.android.material.bottomnavigation.BottomNavigationView;

import org.json.JSONArray;
import org.json.JSONException;
import org.json.JSONObject;

import java.io.IOException;
import java.util.HashMap;
import java.util.List;
import java.util.Locale;
import java.util.Map;

public class MainActivity extends AppCompatActivity implements LocationListener {
    LocationManager locationManager;
    double latitude, longitude;
    String city = "", stateName="";

    public static final int MY_PERMISSIONS_REQUEST_LOCATION = 99;
    public static final String EXTRA_KEYWORD = "keyword";

    @Override
    protected void onCreate(Bundle savedInstanceState) {
        setTheme(R.style.AppTheme);
        super.onCreate(savedInstanceState);
        setContentView(R.layout.activity_main);
        checkLocationPermission();
        Toolbar toolbar = findViewById(R.id.toolbar);
        setSupportActionBar(toolbar);
        final SharedPreferences sharedPreferences = getSharedPreferences("bookmarks",MODE_PRIVATE);
        final SharedPreferences.Editor editor = sharedPreferences.edit();
//        editor.clear();
//        editor.apply();
//        setContentView(R.layout.activity_main);

        openFragment(new HomeFragment());
        final BottomNavigationView bottomNavigation = findViewById(R.id.bottom_navigation);


        bottomNavigation.setOnNavigationItemSelectedListener(
                new BottomNavigationView.OnNavigationItemSelectedListener() {
                    @SuppressLint("ResourceAsColor")
                    @Override public boolean onNavigationItemSelected(@NonNull MenuItem item) {
                        switch (item.getItemId()) {
                            case R.id.navigation_home:
                                openFragment(new HomeFragment());
                                return true;
                            case R.id.navigation_trending:
                                openFragment(new TrendingFragment());
                                return true;
                            case R.id.navigation_headlines:
                                openFragment(new HeadlinesFragment());
                                return true;
                            case R.id.navigation_bookmark:
                                openFragment(new BookmarkFragment());
                                return true;
                        }
                        return false;
                    }
                });
//
    }

    @Override
    public boolean onCreateOptionsMenu(Menu menu) {
        MenuInflater menuInflater = getMenuInflater();
        menuInflater.inflate(R.menu.action_bar_search_example_menu, menu);
        MenuItem searchMenu = menu.findItem(R.id.app_bar_menu_search);
        SearchManager searchManager = (SearchManager) getSystemService(Context.SEARCH_SERVICE);

        final androidx.appcompat.widget.SearchView searchView = (androidx.appcompat.widget.SearchView) searchMenu.getActionView();
        final androidx.appcompat.widget.SearchView.SearchAutoComplete autoSuggestions = searchView.findViewById(androidx.appcompat.R.id.search_src_text);

       //ArrayAdapter<String> newsempty;
        searchView.setIconified(true);
        searchView.setIconifiedByDefault(true);
        searchView.setSearchableInfo(searchManager.getSearchableInfo(getComponentName()));

        autoSuggestions.setOnItemClickListener(new AdapterView.OnItemClickListener() {
            @Override
            public void onItemClick(AdapterView<?> parentClick, View viewClick, int positionClick, long id) {
                SearchView.SearchAutoComplete search = searchView.findViewById(androidx.appcompat.R.id.search_src_text);
                Intent sendSearchIntent = new Intent(viewClick.getContext(), SearchActivity.class);
                String search_keyword = (String) parentClick.getItemAtPosition(positionClick);
                sendSearchIntent.putExtra(EXTRA_KEYWORD, search_keyword);
                search.setText(search_keyword);
//                startActivity(sendSearchIntent);
            }
        });

        searchView.setOnQueryTextListener(new SearchView.OnQueryTextListener() {
            @Override
            public boolean onQueryTextSubmit(String keyword) {
                Intent searchIntent = new Intent(MainActivity.this , SearchActivity.class);
                searchIntent.putExtra(EXTRA_KEYWORD,keyword);
                startActivity(searchIntent);
                return true;
            }
            @Override
            public boolean onQueryTextChange(String newText) {
                Intent searchIntent = new Intent(MainActivity.this , SearchActivity.class);
                if(newText.length() < 2) {
                    ArrayAdapter<String> newsempty = null;
                    autoSuggestions.setAdapter(newsempty);
                    return true;
                }
                String temp = "hw9 here";

                generateSuggestions(newText, autoSuggestions);

                if (temp.length() > 0)
                {
                    temp += "today";
                }
                return true;
            }
        });
        return true;
    }

    private void openFragment(Fragment fragment) {
        FragmentTransaction transaction = getSupportFragmentManager().beginTransaction();
        transaction.replace(R.id.container, fragment);
        transaction.addToBackStack(null);
        transaction.commit();
    }

    private void generateSuggestions(String query, final androidx.appcompat.widget.SearchView.SearchAutoComplete auto_suggestions) {
        Intent searchIntent = new Intent(MainActivity.this , SearchActivity.class);
        final String dummyText = "android hw9 is due today at 11:59pm";
        searchIntent.putExtra(EXTRA_KEYWORD,query);
        String url = "https://harshal-kapadia.cognitiveservices.azure.com/bing/v7.0/suggestions?q="+query;
        RequestQueue bingVolleyRequest = Volley.newRequestQueue(getBaseContext());

        JsonObjectRequest JsonRequestBing = new JsonObjectRequest(Request.Method.GET, url,
                null, new Response.Listener<JSONObject>() {
            @Override
            public void onResponse(JSONObject response) {
                try {
                    String[] suggested_arr = new String[5];
                    JSONArray autoSuggestionsArray = response.getJSONArray("suggestionGroups").getJSONObject(0).getJSONArray("searchSuggestions");
                    int limit = Math.min(autoSuggestionsArray.length(), 5);

                    if (dummyText.length() == 5){
                        String dummy = dummyText + dummyText.length() + "is the length";
                    }

                    for (int i = 0; i<limit; i++) {
                        try {
                            suggested_arr[i] = autoSuggestionsArray.getJSONObject(i).getString("displayText");
                        } catch (JSONException e) {
                            e.printStackTrace();
                        }
                    }
                    ArrayAdapter<String> arrayAdapter = new ArrayAdapter<String>(MainActivity.this, android.R.layout.simple_dropdown_item_1line, suggested_arr);
                    auto_suggestions.setAdapter(arrayAdapter);
                } catch (JSONException err) {
                    err.printStackTrace();
                }
            }
        }, new Response.ErrorListener() {
            @Override
            public void onErrorResponse(VolleyError error) {
                error.printStackTrace();
            }
        }){
            @Override
            public Map<String, String> getHeaders() {
                Map <String, String> bingAutoSuggestKey = new HashMap<>();
                bingAutoSuggestKey.put("Ocp-Apim-Subscription-Key", "002f929c735f49ad84143ba5cee88a7f");
                return bingAutoSuggestKey;
            }
        };
        bingVolleyRequest.add(JsonRequestBing);
    }

    private void checkLocationPermission() {
        if (ActivityCompat.checkSelfPermission(this, Manifest.permission.ACCESS_FINE_LOCATION)
                != PackageManager.PERMISSION_GRANTED &&
                ActivityCompat.checkSelfPermission(this, Manifest.permission.ACCESS_COARSE_LOCATION)
                        != PackageManager.PERMISSION_GRANTED) {
            ActivityCompat.requestPermissions(this, new String[]{
                    Manifest.permission.ACCESS_FINE_LOCATION}, 1);

        } else {
            // Write you code here if permission already given.
            locationManager = (LocationManager) getSystemService(Context.LOCATION_SERVICE);
            if (locationManager != null) {
                locationManager.requestLocationUpdates(LocationManager.GPS_PROVIDER, 0, 5, (LocationListener) this);
            }
        }
    }

    @Override
    public void onRequestPermissionsResult(int requestCode, String permissions[], int[] grantResults) {
        switch (requestCode) {
            case MY_PERMISSIONS_REQUEST_LOCATION: {
                // If request is cancelled, the result arrays are empty.
                if (grantResults.length > 0
                        && grantResults[0] == PackageManager.PERMISSION_GRANTED) {
                    if (ContextCompat.checkSelfPermission(this,
                            Manifest.permission.ACCESS_FINE_LOCATION)
                            == PackageManager.PERMISSION_GRANTED) {
                        locationManager.requestLocationUpdates(LocationManager.GPS_PROVIDER,
                                0, 5, (LocationListener) this);
                    }
                }
            }
        }
    }

    @Override
    public void onLocationChanged(Location location) {
        Geocoder geocoder = new Geocoder(this, Locale.getDefault());
        List<Address> addresses = null;
        latitude = location.getLatitude();
        longitude = location.getLongitude();
        try {
            addresses = geocoder.getFromLocation(latitude, longitude, 1);
//            Log.d(TAG, addresses.toString());
        } catch (IOException e) {
            e.printStackTrace();
        }
        city = addresses.get(0).getLocality();
        stateName = addresses.get(0).getAdminArea();
        openFragment(new HomeFragment());
//        Log.d("MainActivity", city+" "+stateName);
    }

    @Override
    public void onStatusChanged(String provider, int status, Bundle extras) {

    }

    @Override
    public void onProviderEnabled(String provider) {

    }

    @Override
    public void onProviderDisabled(String provider) {

    }


}
