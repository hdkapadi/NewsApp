package com.example.hw9;

public class ExampleItem {
    private String mImageUrl;
    private String newsTitle;
    private String pub_date;
    private String sect;
    private String article;
    private String webUrl;


    public ExampleItem(String imageUrl, String title, String date, String sectionName, String article_id, String web_url) {
        mImageUrl = imageUrl;
        newsTitle = title;
        pub_date = date + " | ";
        sect = sectionName;
        article = article_id;
        webUrl = web_url;

    }

    public String getImageUrl()
    {
        return mImageUrl;
    }

    public String getCreator()
    {
        return newsTitle;
    }

    public String getSection()
    {
        return sect;
    }

    public String getLikeCount()
    {
        return pub_date;
    }

    public String getid()
    {
        return article;
    }

    public String geturl(){
        return webUrl;
    }

}
