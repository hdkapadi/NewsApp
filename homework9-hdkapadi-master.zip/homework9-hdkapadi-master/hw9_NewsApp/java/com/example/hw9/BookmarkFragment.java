package com.example.hw9;

import android.app.Dialog;
import android.content.Intent;
import android.content.SharedPreferences;
import android.net.Uri;
import android.os.Bundle;
import org.json.*;

import androidx.cardview.widget.CardView;
import androidx.fragment.app.Fragment;
import androidx.recyclerview.widget.DividerItemDecoration;
import androidx.recyclerview.widget.GridLayoutManager;
import androidx.recyclerview.widget.RecyclerView;

import android.preference.PreferenceManager;
import android.util.Log;
import android.view.LayoutInflater;
import android.view.View;
import android.view.ViewGroup;
import android.widget.ImageView;
import android.widget.TextView;
import android.widget.Toast;

import com.squareup.picasso.Picasso;

import org.json.JSONObject;
import org.w3c.dom.Text;

import java.util.ArrayList;
import java.util.Arrays;
import java.util.List;
import java.util.Map;


/**
 * A simple {@link Fragment} subclass.
 */
public class BookmarkFragment extends Fragment implements MyAdapter.OnItemClickListener, MyAdapter.OnItemLongClickListener{
    List< FlowerData > mFlowerList;
    FlowerData mFlowerData;
    ExampleItem exampleItem;
    private ArrayList<ExampleItem> articleList;
    private ExampleAdapter mExampleAdapter;
    private MyAdapter myAdapter;
    private RecyclerView recyclerView;
    private View view;
    public static final String EXTRA_URL = "imageUrl";
    public static final String EXTRA_CREATOR = "creatorName";
    public static final String EXTRA_LIKES = "likeCount";
    public static final String EXTRA = "sect";
    public static final String ID = "id";
    TextView textView;
    public static final String DETAIL = "detail_date";
    public final String MyBook = "bookmarks";


    public BookmarkFragment() {
        // Required empty public constructor
    }


    @Override
    public View onCreateView(LayoutInflater inflater, ViewGroup container,
                             Bundle savedInstanceState) {
        // Inflate the layout for this fragment
        super.onCreate(savedInstanceState);
        view= inflater.inflate(R.layout.fragment_bookmark, container, false);
         textView = view.findViewById(R.id.bktext);
        CardView cardView = view.findViewById(R.id.cardview);
       recyclerView = view.findViewById(R.id.bookmark_recycler_view);
//        TextView textView_bk = view.findViewById(R.id.bktext);

        GridLayoutManager gridLayoutManager = new GridLayoutManager(getContext(),2);
        recyclerView.setLayoutManager(gridLayoutManager);
        DividerItemDecoration dividerItemDecoration = new DividerItemDecoration(recyclerView.getContext(),
                gridLayoutManager.getOrientation());
        recyclerView.addItemDecoration(dividerItemDecoration);
        SharedPreferences sharedPreferences = getContext().getSharedPreferences("bookmarks",0);
        SharedPreferences.Editor editor = sharedPreferences.edit();

        Map<String,?> keys1 = sharedPreferences.getAll();
        if (keys1.size() == 0){
            textView.setVisibility(View.VISIBLE);
//            textView.setText("No Bookmarked Articles");
        }

        Map<String,?> keys = sharedPreferences.getAll();
        if (keys.toString().length() == 0){
            System.out.println("inside second if");
            textView.setVisibility(View.VISIBLE);
            cardView.setVisibility(View.GONE);
            textView.setText("No Bookmarked Articles");
        }
        else {
            articleList = new ArrayList<>();
            for (Map.Entry<String, ?> entry : keys.entrySet()) {
                //articleList.add(entry.getKey());
                String data = sharedPreferences.getString(entry.getKey(),"");
                try {
                    JSONObject jsonObject = new JSONObject(data);

                    String imageUrl = jsonObject.getString("imageUrl");
                    String title = jsonObject.getString("title");
                    String date = jsonObject.getString("date");
                    //String date1 = jsonObject.getString("detail_date");
                    String section = jsonObject.getString("section");
                    String webUrl = jsonObject.getString("web_url");
                    String articleId = entry.getKey();

                    articleList.add(new ExampleItem(imageUrl,title,date,section,articleId,webUrl));

                } catch (JSONException e) {
                    e.printStackTrace();
                }
            }
            myAdapter = new MyAdapter(getActivity(),articleList,textView);
            recyclerView.setAdapter(myAdapter);
            myAdapter.notifyDataSetChanged();
            myAdapter.setOnItemClickListener(BookmarkFragment.this);
            myAdapter.setOnItemLongClickListener(BookmarkFragment.this);

        }
        return  view;
    }
    public void onItemClick(int position) {
        JSONObject obj = new JSONObject();
        Intent detailIntent = new Intent(getActivity(), DetailActivity.class);
        ExampleItem clickedItem = articleList.get(position);

        detailIntent.putExtra(EXTRA_URL, clickedItem.getImageUrl());
        detailIntent.putExtra(EXTRA_CREATOR, clickedItem.getCreator());
        detailIntent.putExtra(EXTRA_LIKES, clickedItem.getLikeCount());
        detailIntent.putExtra(EXTRA,clickedItem.getSection());
        detailIntent.putExtra(ID,clickedItem.getid());
        startActivity(detailIntent);
    }

    @Override
    public void onItemLongClick(int p) {
        final JSONObject obj = new JSONObject();
        SharedPreferences sharedPreferences = getContext().getSharedPreferences(MyBook,0);
        final SharedPreferences.Editor editor = sharedPreferences.edit();
        final ExampleItem item = articleList.get(p);
        final Dialog dialog = new Dialog(getContext());
        dialog.setContentView(R.layout.dialog);

        final String articleId = item.getid();
        final String title = item.getCreator();
        String date = item.getLikeCount();
        String section = item.getSection();
        String imageUrl = item.getImageUrl();
        final String web_url = item.geturl();

        try {
            obj.put("imageUrl",imageUrl);
            obj.put("title",title);
            obj.put("date",date);
            obj.put("section",section);
            obj.put("web_url",web_url);
        } catch (JSONException e) {
            e.printStackTrace();
        }
        ImageView imageView = dialog.findViewById(R.id.dialog_image);
        Picasso.with(getContext()).load(imageUrl).into(imageView);
        TextView textView2 = dialog.findViewById(R.id.dialog_text);

        final TextView textView1 = dialog.findViewById(R.id.bktext);

        textView2.setText(item.getCreator());
        ImageView imageView1 = dialog.findViewById(R.id.dialog_twitter);
        imageView1.setImageResource(R.drawable.bluetwitter);
        final ImageView imageView2 = dialog.findViewById(R.id.dialog_bookmark);
        final ImageView imageView3 = dialog.findViewById(R.id.dialog_bookmark1);
//
        if (sharedPreferences.contains(articleId)){
            imageView2.setVisibility(View.GONE);
            imageView3.setVisibility(View.VISIBLE);
            imageView3.setOnClickListener(new View.OnClickListener() {
                @Override
                public void onClick(View v) {
                    imageView2.setVisibility(View.VISIBLE);
                    imageView3.setVisibility(View.GONE);
                    editor.remove(articleId);
                    editor.apply();
                    Toast.makeText(getContext(), "\""+title+"\" was removed from bookmarks", Toast.LENGTH_SHORT).show();
                    articleList.remove(item);
                    if (articleList.size() == 0){
                        textView.setVisibility(View.VISIBLE);
                    }
                    myAdapter.notifyDataSetChanged();
                    dialog.dismiss();
                }
            });
        }
        //remove from bookmark
        imageView3.setOnClickListener(new View.OnClickListener() {
            @Override
            public void onClick(View v) {
                imageView2.setVisibility(View.VISIBLE);
                imageView3.setVisibility(View.GONE);
                editor.remove(articleId);
                editor.apply();
                Toast.makeText(getContext(), "\""+title+"\" was removed from bookmarks", Toast.LENGTH_SHORT).show();
                articleList.remove(item);
                myAdapter.notifyDataSetChanged();
                dialog.dismiss();
                if (articleList.size() == 0){
                    Log.i("list size","updated^^^^^");
                    textView.setVisibility(View.VISIBLE);
                }
            }
        });

        imageView1.setOnClickListener(new View.OnClickListener() {
            @Override
            public void onClick(View v) {
                String url = "http://www.twitter.com/intent/tweet?text=Check%20out%20this%20Link:%20" +web_url+ "&hashtags=CSCI571NewsSearch";
                Intent i = new Intent(Intent.ACTION_VIEW);
                i.setData(Uri.parse(url));
                startActivity(i);
            }
        });

        dialog.show();
    }

    @Override
    public void onResume() {
        super.onResume();

        SharedPreferences sharedPreferences = getContext().getSharedPreferences("bookmarks", 0);
        TextView textViewbk = getView().findViewById(R.id.bktext);

        Map<String, ?> keys1 = sharedPreferences.getAll();
        if (keys1.size() == 0) {
            Log.i("inside if----","size is 0");
            textView.setVisibility(View.VISIBLE);
            recyclerView.setVisibility(View.GONE);
        }
        else {
            Log.i("inside else",keys1.size()+" is the size");
            textView.setVisibility(View.GONE);
            articleList = new ArrayList<>();
            for (Map.Entry<String, ?> entry : keys1.entrySet()) {
                String data = sharedPreferences.getString(entry.getKey(), "");
                try {
                    JSONObject jsonObject = new JSONObject(data);
                    String imageUrl = jsonObject.getString("imageUrl");
                    String title = jsonObject.getString("title");
                    String date = jsonObject.getString("date");
                    //String date1 = jsonObject.getString("detail_date");
                    String section = jsonObject.getString("section");
                    String webUrl = jsonObject.getString("web_url");
                    String articleId = entry.getKey();

                    articleList.add(new ExampleItem(imageUrl, title, date, section, articleId, webUrl));

                } catch (JSONException e) {
                    e.printStackTrace();
                }
            }
            myAdapter = new MyAdapter(getActivity(), articleList, textView);
            recyclerView.setAdapter(myAdapter);
            myAdapter.notifyDataSetChanged();
            myAdapter.setOnItemClickListener(BookmarkFragment.this);
            myAdapter.setOnItemLongClickListener(BookmarkFragment.this);
        }
    }
}
