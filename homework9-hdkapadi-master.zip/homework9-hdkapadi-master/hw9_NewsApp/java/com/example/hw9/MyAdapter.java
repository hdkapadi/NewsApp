//package com.example.hw9;
//
//import android.content.Context;
//import android.view.LayoutInflater;
//import android.view.View;
//import android.view.ViewGroup;
//import android.widget.ImageView;
//import android.widget.TextView;
//
//import androidx.annotation.NonNull;
//import androidx.recyclerview.widget.RecyclerView;
//
//import java.util.List;
//
//public class MyAdapter extends RecyclerView.Adapter<MyAdapter.FlowerViewHolder> {
//    private Context mContext;
//    private List<FlowerData> mFlowerList;
//
//    MyAdapter(Context mContext, List<FlowerData> mFlowerList) {
//        this.mContext = mContext;
//        this.mFlowerList = mFlowerList;
//    }
//
//    @NonNull
//    @Override
//    public FlowerViewHolder onCreateViewHolder(@NonNull ViewGroup parent, int viewType) {
//        View mView = LayoutInflater.from(parent.getContext()).inflate(R.layout.bookmark_grid, parent, false);
//        return new FlowerViewHolder(mView);
//    }
//
//    @Override
//    public void onBindViewHolder(@NonNull MyAdapter.FlowerViewHolder holder, int position) {
//        holder.mImage.setImageResource(mFlowerList.get(position).getFlowerImage());
//        holder.mTitle.setText(mFlowerList.get(position).getFlowerName());
//    }
//
//
//
//    @Override
//    public int getItemCount() {
//        return mFlowerList.size();
//    }
//
//
//    class FlowerViewHolder extends RecyclerView.ViewHolder {
//        ImageView mImage;
//        TextView mTitle;
//
//        FlowerViewHolder(View itemView) {
//            super(itemView);
//            mImage = itemView.findViewById(R.id.ivImage);
//            mTitle = itemView.findViewById(R.id.tvTitle);
//        }
//    }
//}
//

package com.example.hw9;

import android.content.Context;
import android.content.SharedPreferences;
import android.os.Build;
import android.util.Log;
import android.view.LayoutInflater;
import android.view.View;
import android.view.ViewGroup;
import android.widget.ImageView;
import android.widget.TextView;
import android.widget.Toast;

import androidx.annotation.RequiresApi;
import androidx.recyclerview.widget.RecyclerView;

import com.squareup.picasso.Picasso;

import org.json.JSONArray;
import org.json.JSONException;
import org.json.JSONObject;

import java.time.LocalDate;
import java.time.LocalDateTime;
import java.util.ArrayList;
import java.util.HashMap;
import java.util.List;
import java.util.Map;

public class MyAdapter extends RecyclerView.Adapter<MyAdapter.MyViewHolder> {
    private Context mContext;
    private ArrayList<ExampleItem> mExampleList;
    private OnItemClickListener mListener;
    private TextView tv1;
    private MyAdapter.OnItemLongClickListener onItemLongClick;
    //private ExampleAdapter.OnItemLongClickListener onItemLongClick;
    public final String MyBook = "bookmarks";
    JSONObject obj = new JSONObject();

//    SharedPreferences sharedPreferences = mContext.getSharedPreferences(MyBook,0);
//    SharedPreferences.Editor editor = sharedPreferences.edit();


    public interface OnItemClickListener
    {
        void onItemClick(int position);
    }

    public interface  OnItemLongClickListener{
        void onItemLongClick(int position);
    }

    public void setOnItemLongClickListener(MyAdapter.OnItemLongClickListener listener){
        onItemLongClick=listener;
    }

    public void setOnItemClickListener(OnItemClickListener listener)
    {
        mListener = listener;
    }

    public MyAdapter(Context context, ArrayList<ExampleItem> exampleList,TextView tv)
    {
        mContext = context;
        mExampleList = exampleList;
        tv1 = tv;
    }

    @Override
    public MyViewHolder onCreateViewHolder(ViewGroup parent, int viewType)
    {
        View v = LayoutInflater.from(mContext).inflate(R.layout.bookmark_grid, parent, false);
        return new MyViewHolder(v);
    }

    @RequiresApi(api = Build.VERSION_CODES.O)
    @Override
    public void onBindViewHolder(MyViewHolder holder, int position)
    {
        SharedPreferences sharedPreferences = mContext.getSharedPreferences(MyBook,Context.MODE_PRIVATE);
        SharedPreferences.Editor editor = sharedPreferences.edit();
        ExampleItem currentItem = mExampleList.get(position);

        String imageUrl = currentItem.getImageUrl();
        String creatorName = currentItem.getCreator();
        String likeCount = currentItem.getLikeCount();
        String name = currentItem.getSection();
        String id = currentItem.getid();

        LocalDate ld = LocalDate.parse(likeCount.substring(0,10));
        String month = ld.getMonth().toString();
        month = month.charAt(0) + month.substring(1,3).toLowerCase();
        String display_date = ld.getDayOfMonth() + " " + month + " | ";

        Map<String,?> keys = sharedPreferences.getAll();
        if (keys.toString().length() == 0){
            System.out.println("inside second if");
            holder.textView.setVisibility(View.VISIBLE);
//                cardView.setVisibility(View.GONE);
            holder.textView.setText("No Bookmarked Articles");
        }

        holder.mTextViewCreator.setText(creatorName);
        holder.mTextViewLikes.setText(display_date);
        holder.sectiontext.setText(name);
        Picasso.with(mContext).load(imageUrl).into(holder.mImageView);
        holder.bookmark_add.setImageResource(R.drawable.filled_book);



//        if (checkbookmark(currentItem)){
//            holder.bookmark_add.setVisibility(View.GONE);
//        }
//        else{
//            holder.bookmark_add.setVisibility(View.VISIBLE);
//        }
    }

//    private boolean checkbookmark(ExampleItem curr){
//        SharedPreferences prefs = mContext.getSharedPreferences(MyBook,0);
//        String art_id = curr.getid();
//        String checkvalue =  prefs.getString(art_id,"");
//        return checkvalue.length() != 0;
//    }

    @Override
    public int getItemCount()
    {
        return mExampleList.size();
    }

    public class MyViewHolder extends RecyclerView.ViewHolder {
        SharedPreferences sharedPreferences = mContext.getSharedPreferences(MyBook,Context.MODE_PRIVATE);
        SharedPreferences.Editor editor = sharedPreferences.edit();

        public ImageView mImageView;
        public TextView mTextViewCreator,textView;
        public TextView mTextViewLikes;
        public TextView sectiontext;
        public ImageView bookmark_add;


        public MyViewHolder(View itemView) {
            super(itemView);
            //ExampleItem exampleItem = mExampleList.get(getAdapterPosition());

            mImageView = itemView.findViewById(R.id.ivImage);
            mTextViewCreator = itemView.findViewById(R.id.tvTitle);
            mTextViewLikes = itemView.findViewById(R.id.bookmark_date);
            sectiontext = itemView.findViewById(R.id.bookmark_section);
            bookmark_add = itemView.findViewById(R.id.bookmark_page);
            textView = itemView.findViewById(R.id.bktext);



            bookmark_add.setOnClickListener(new View.OnClickListener() {
                @Override
                public void onClick(View v) {
                    ExampleItem item = mExampleList.get(getAdapterPosition());
                    String articleId = item.getid();
                    String title = item.getCreator();
                    Toast.makeText(mContext, "\"" + title + "\" was removed from bookmarks", Toast.LENGTH_SHORT).show();
                    editor.remove(articleId);
                    editor.apply();
                    mExampleList.remove(item);
                    if (mExampleList.size() == 0){
                        tv1.setVisibility(View.VISIBLE);
                    }
                    notifyDataSetChanged();

                }
            });



            itemView.setOnClickListener(new View.OnClickListener() {
                @Override
                public void onClick(View v) {
                    if (mListener != null) {
                        int position = getAdapterPosition();
                        if (position != RecyclerView.NO_POSITION) {
                            mListener.onItemClick(position);
                        }
                    }
                }
            });

            itemView.setOnLongClickListener(new View.OnLongClickListener() {
                @Override
                public boolean onLongClick(View v) {
                    if (mListener != null){
                        int pos = getAdapterPosition();
                        if (pos != RecyclerView.NO_POSITION){
                            onItemLongClick.onItemLongClick(pos);
                        }
                    }
                    return true;
                }
            });
        }
    }
}