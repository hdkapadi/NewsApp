package com.example.hw9;

import android.content.Context;
import android.content.SharedPreferences;
import android.util.Log;
import android.view.LayoutInflater;
import android.view.View;
import android.view.ViewGroup;
import android.widget.ImageView;
import android.widget.TextView;
import android.widget.Toast;

import androidx.recyclerview.widget.RecyclerView;

import com.squareup.picasso.Picasso;

import org.json.JSONArray;
import org.json.JSONException;
import org.json.JSONObject;

import java.text.ParseException;
import java.text.SimpleDateFormat;
import java.util.ArrayList;
import java.util.Date;
import java.util.HashMap;
import java.util.List;
import java.util.Map;
import java.util.TimeZone;
import java.util.concurrent.TimeUnit;

public class ExampleAdapter extends RecyclerView.Adapter<ExampleAdapter.ExampleViewHolder> {
    private Context mContext;
    private ArrayList<ExampleItem> mExampleList;
    private OnItemClickListener mListener;
    private OnItemLongClickListener onItemLongClick;
    public final String MyBook = "bookmarks";
    JSONObject obj = new JSONObject();

//    SharedPreferences sharedPreferences = mContext.getSharedPreferences(MyBook,0);
//    SharedPreferences.Editor editor = sharedPreferences.edit();


    public interface OnItemClickListener
    {
        void onItemClick(int position);
        //void onItemLongClick(int pos);
    }

    public interface  OnItemLongClickListener{
        void onItemLongClick(int position);
    }

    public void setOnItemLongClickListener(OnItemLongClickListener listener){
        onItemLongClick=listener;
    }

    public void setOnItemClickListener(OnItemClickListener listener)
    {
        mListener = listener;
    }

    public ExampleAdapter(Context context, ArrayList<ExampleItem> exampleList)
    {
        mContext = context;
        mExampleList = exampleList;
    }

    @Override
    public ExampleViewHolder onCreateViewHolder(ViewGroup parent, int viewType)
    {
        View v = LayoutInflater.from(mContext).inflate(R.layout.example_item, parent, false);
        return new ExampleViewHolder(v);
    }

    @Override
    public void onBindViewHolder(ExampleViewHolder holder, int position)
    {
        ExampleItem currentItem = mExampleList.get(position);

        String imageUrl = currentItem.getImageUrl();
        String creatorName = currentItem.getCreator();
        String likeCount = currentItem.getLikeCount();
        String name = currentItem.getSection();
        String id = currentItem.getid();
        String web_url = currentItem.geturl();

        holder.mTextViewCreator.setText(creatorName);
        holder.mTextViewCreator1.setText(creatorName);
        holder.mTextViewLikes.setText(convertTime(likeCount.substring(0,likeCount.length()-3)));
        holder.sectiontext.setText(name);
        Picasso.with(mContext).load(imageUrl).fit().centerInside().into(holder.mImageView);

        if (checkbookmark(currentItem)){
            holder.bookmark_add.setVisibility(View.GONE);
            holder.bookmark_remove.setVisibility(View.VISIBLE);
            holder.mTextViewCreator.setVisibility(View.GONE);
            holder.mTextViewCreator1.setVisibility(View.VISIBLE);

        }
        else{
            holder.bookmark_add.setVisibility(View.VISIBLE);
            holder.bookmark_remove.setVisibility(View.GONE);
            holder.mTextViewCreator.setVisibility(View.VISIBLE);
            holder.mTextViewCreator1.setVisibility(View.GONE);
        }
    }

    private boolean checkbookmark(ExampleItem curr)
    {
        SharedPreferences prefs = mContext.getSharedPreferences(MyBook,0);
        String art_id = curr.getid();
        String checkvalue =  prefs.getString(art_id,"");
        return checkvalue.length() != 0;
    }

    private String convertTime(String date){
        String time = null;
        String suffix = "ago";

        try {
            SimpleDateFormat dateFormat = new SimpleDateFormat("yyyy-MM-dd'T'HH:mm:ss'Z'");
            Date nowTime = new Date();
            TimeZone gmtTime = TimeZone.getTimeZone("PST");
            dateFormat.setTimeZone(gmtTime);
            Date pasTime = dateFormat.parse(date);

//            Log.i("NOW TIME---", String.valueOf(nowTime.getTime()));
//            Log.i("PAST TIME***", String.valueOf(pasTime.getTime()));

            long dateDiff =  nowTime.getTime() - pasTime.getTime();
//            if (dateDiff<0){
//                dateDiff = pasTime.getTime() - nowTime.getTime();
//            }

            long second = TimeUnit.MILLISECONDS.toSeconds(dateDiff);
            long minute = TimeUnit.MILLISECONDS.toMinutes(dateDiff);
            long hour   = TimeUnit.MILLISECONDS.toHours(dateDiff);
            long day  = TimeUnit.MILLISECONDS.toDays(dateDiff);

            if (second < 60) {
                time = second+"s "+suffix + " | ";
            }
            else if (minute < 60) {
                time = minute+"m "+suffix+ " | ";
            }
            else if (hour < 24) {
                time = hour+"h "+suffix+ " | ";
            }
            else {
                time = day + "d " + suffix+ " | ";
            }
        }catch (ParseException e) {
            e.printStackTrace();
//            Log.e("ConvTimeE", e.getMessage());
        }
        return time;
    }

    @Override
    public int getItemCount()
    {
        return mExampleList.size();
    }

    public class ExampleViewHolder extends RecyclerView.ViewHolder {
        SharedPreferences sharedPreferences = mContext.getSharedPreferences(MyBook,Context.MODE_PRIVATE);
        SharedPreferences.Editor editor = sharedPreferences.edit();

        public ImageView mImageView;
        public TextView mTextViewCreator,mTextViewCreator1;
        public TextView mTextViewLikes;
        public TextView sectiontext;
        public ImageView bookmark_add,bookmark_remove;

        public ExampleViewHolder(View itemView) {
            super(itemView);
            //ExampleItem exampleItem = mExampleList.get(getAdapterPosition());

            mImageView = itemView.findViewById(R.id.image_view);
            mTextViewCreator = itemView.findViewById(R.id.text_view_creator);
            mTextViewCreator1 = itemView.findViewById(R.id.text_view_creator1);
            mTextViewLikes = itemView.findViewById(R.id.text_view_likes);
            sectiontext = itemView.findViewById(R.id.textView6);
            bookmark_add = itemView.findViewById(R.id.imageView);
            bookmark_remove= itemView.findViewById(R.id.imageView1);

            bookmark_remove.setOnClickListener(new View.OnClickListener() {
                @Override
                public void onClick(View v) {
                    ExampleItem item = mExampleList.get(getAdapterPosition());
                    String articleId = item.getid();
                    String title = item.getCreator();
                    bookmark_add.setVisibility(View.VISIBLE);
                    bookmark_remove.setVisibility(View.GONE);
                    mTextViewCreator.setVisibility(View.VISIBLE);
                    mTextViewCreator1.setVisibility(View.GONE);
                    Toast.makeText(mContext, "\"" + title + "\" was removed from bookmarks", Toast.LENGTH_SHORT).show();
                    editor.remove(articleId);
                    editor.apply();
                }
            });

            bookmark_add.setOnClickListener(new View.OnClickListener() {
                @Override
                public void onClick(View v) {
                    ExampleItem item = mExampleList.get(getAdapterPosition());
                    JSONObject obj = new JSONObject();
                    String image = item.getImageUrl();
                    String title = item.getCreator();
                    String date = item.getLikeCount();
                    String sect = item.getSection();
                    String id = item.getid();
                    String web_url = item.geturl();


                    try {
                        obj.put("imageUrl",image);
                        obj.put("title",title);
                        obj.put("date",date);
                        obj.put("section",sect);
                        obj.put("web_url",web_url);

                    } catch (JSONException e) {
                        e.printStackTrace();
                    }
                    bookmark_add.setVisibility(View.GONE);
                    bookmark_remove.setVisibility(View.VISIBLE);
                    mTextViewCreator.setVisibility(View.GONE);
                    mTextViewCreator1.setVisibility(View.VISIBLE);
                    Toast.makeText(mContext, "\"" + title + "\" was added to bookmarks", Toast.LENGTH_SHORT).show();
                    editor.putString(id,obj.toString());
                    editor.apply();
                }
            });

            itemView.setOnClickListener(new View.OnClickListener() {
                @Override
                public void onClick(View v) {
                    if (mListener != null) {
                        int position = getAdapterPosition();
                        if (position != RecyclerView.NO_POSITION) {
                            mListener.onItemClick(position);
                        }
                    }
                }
            });
            itemView.setOnLongClickListener(new View.OnLongClickListener() {
                @Override
                public boolean onLongClick(View v) {
                    if (mListener != null){
                        int pos = getAdapterPosition();
                        if (pos != RecyclerView.NO_POSITION){
                            onItemLongClick.onItemLongClick(pos);
                        }
                    }
                    return true;
                }
            });
        }
    }


}