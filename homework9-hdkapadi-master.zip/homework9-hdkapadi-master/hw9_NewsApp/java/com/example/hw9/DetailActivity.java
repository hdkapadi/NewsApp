package com.example.hw9;

import android.app.Activity;
import android.content.Intent;
import android.content.SharedPreferences;
import android.graphics.Paint;
import android.net.Uri;
import android.os.Build;
import android.os.Bundle;
import android.os.Handler;
import android.text.method.LinkMovementMethod;
import android.util.Log;
import android.view.LayoutInflater;
import android.view.View;
import android.view.ViewGroup;
import android.widget.ImageView;
import android.widget.ProgressBar;
import android.widget.TextView;
import android.widget.Toast;

import androidx.annotation.Nullable;
import androidx.appcompat.widget.Toolbar;

import androidx.annotation.RequiresApi;
import androidx.appcompat.app.AppCompatActivity;
import androidx.cardview.widget.CardView;

import com.android.volley.Request;
import com.android.volley.RequestQueue;
import com.android.volley.Response;
import com.android.volley.VolleyError;
import com.android.volley.toolbox.JsonObjectRequest;
import com.android.volley.toolbox.Volley;
import com.squareup.picasso.Picasso;
import org.json.JSONArray;
import org.json.JSONException;
import org.json.JSONObject;
import org.jsoup.Jsoup;

import java.time.LocalDate;
import java.time.LocalDateTime;
import java.time.ZoneId;
import java.time.ZonedDateTime;
import java.util.ArrayList;
import java.util.Map;
import java.util.Set;

import static com.example.hw9.HomeFragment.DETAIL;
import static com.example.hw9.HomeFragment.EXTRA_CREATOR;
import static com.example.hw9.HomeFragment.EXTRA_LIKES;
import static com.example.hw9.HomeFragment.EXTRA_URL;
import static com.example.hw9.HomeFragment.EXTRA;
import static com.example.hw9.HomeFragment.EXTRA_WEBURL;
import static com.example.hw9.HomeFragment.ID;
//import static java.lang.System.load;

public class DetailActivity extends AppCompatActivity {
    public final String MyBook = "bookmarks";
    private RequestQueue mRequestQueue;
    private boolean dataReceived;
    private JSONObject res;
    private ProgressBar spinner;

    protected void onCreate(Bundle savedInstanceState) {
        super.onCreate(savedInstanceState);
        final SharedPreferences sharedPreferences = getSharedPreferences(MyBook,MODE_PRIVATE);
        final SharedPreferences.Editor editor = sharedPreferences.edit();
        setContentView(R.layout.activity_detail);
        Intent intent = getIntent();

        final String imageUrl = intent.getStringExtra(EXTRA_URL);

        final String newsTitle = intent.getStringExtra(EXTRA_CREATOR);

        final String pub_date = intent.getStringExtra(EXTRA_LIKES);

        final String sec = intent.getStringExtra(EXTRA);

        final String id = intent.getStringExtra(ID);

        final String web_url = intent.getStringExtra(EXTRA_WEBURL);

        //the back button for action bar.
        Toolbar toolbar = (Toolbar) findViewById(R.id.toolbar_detail);
        setSupportActionBar(toolbar);
        getSupportActionBar().setDisplayHomeAsUpEnabled(true);
        getSupportActionBar().setDisplayShowHomeEnabled(true);

        toolbar.setNavigationOnClickListener(new View.OnClickListener() {
            @Override
            public void onClick(View v) {
                onBackPressed();
            }
        });
        spinner = (ProgressBar)findViewById(R.id.progressBar_detail);

        final ImageView imageView = findViewById(R.id.image_view_detail);
        final TextView expandTitle = findViewById(R.id.text_view_creator_detail);
        final TextView date = findViewById(R.id.text_view_like_detail);
        final TextView textViewSec = findViewById(R.id.textView8);
        final TextView description = findViewById(R.id.article_description);
        final TextView actionBarTitle = findViewById(R.id.textView9);
        final TextView actionBarTitle1 = findViewById(R.id.textView10);

        final TextView artUrl = findViewById(R.id.articleUrl);
        artUrl.setPaintFlags(artUrl.getPaintFlags() | Paint.UNDERLINE_TEXT_FLAG);

        final ImageView bookmark_add = findViewById(R.id.expbookmark);
        final ImageView bookmark_remove= findViewById(R.id.expbookmark1);
        final ImageView twitter_icon = findViewById(R.id.twitter_detail);

        //onclick for twitter
        twitter_icon.setOnClickListener(new View.OnClickListener() {
            @Override
            public void onClick(View v) {
                String url = "http://www.twitter.com/intent/tweet?text=Check%20out%20this%20Link:%20" +web_url+ "&hashtags=CSCI571NewsSearch";
                Intent i = new Intent(Intent.ACTION_VIEW);
                i.setData(Uri.parse(url));
                startActivity(i);
            }
        });


        bookmark_remove.setOnClickListener(new View.OnClickListener() {
            @Override
            public void onClick(View v) {
                bookmark_add.setVisibility(View.VISIBLE);
                bookmark_remove.setVisibility(View.GONE);
                actionBarTitle.setVisibility(View.VISIBLE);
                actionBarTitle1.setVisibility(View.GONE);
                Toast.makeText(getApplicationContext(), "\"" + newsTitle + "\" was removed from bookmarks", Toast.LENGTH_SHORT).show();
                editor.remove(id);
                editor.apply();
            }
        });

        bookmark_add.setOnClickListener(new View.OnClickListener() {
            @Override
            public void onClick(View v) {
                //ExampleItem item = mExampleList.get(getAdapterPosition());
                JSONObject obj = new JSONObject();
                try {
                    obj.put("imageUrl",imageUrl);
                    obj.put("title",newsTitle);
                    obj.put("date",pub_date);
                    obj.put("section",sec);
                    obj.put("web_url",web_url);
                } catch (JSONException e) {
                    e.printStackTrace();
                }
                expandTitle.setMaxLines(1);
                bookmark_add.setVisibility(View.GONE);
                bookmark_remove.setVisibility(View.VISIBLE);
                actionBarTitle.setVisibility(View.GONE);
                actionBarTitle1.setVisibility(View.VISIBLE);
                Toast.makeText(getApplicationContext(), "\"" + newsTitle + "\" was added to bookmarks", Toast.LENGTH_SHORT).show();
                editor.putString(id,obj.toString());
                editor.apply();
            }
        });

        mRequestQueue = Volley.newRequestQueue(getApplicationContext());

        final CardView cardView = findViewById(R.id.detail_card);
        dataReceived = false;
        parseJSON(id);
        cardView.setVisibility(View.GONE);
        final Handler handler = new Handler();
        Runnable runnable = new Runnable() {
            @RequiresApi(api = Build.VERSION_CODES.O)
            @Override
            public void run() {
                if(dataReceived) {
                    spinner.setVisibility(View.GONE);
                    TextView textView2 = findViewById(R.id.progress_text_detail);
                    textView2.setVisibility(View.GONE);
                    cardView.setVisibility(View.VISIBLE);
                    displayData();
                }
                else {
                    handler.postDelayed(this, 1000);
                }
            }
        };
        handler.post(runnable);
        
        String url = "https://hw9-backend-276422.wl.r.appspot.com/detail?art_id=" + id;
        JsonObjectRequest request = new JsonObjectRequest(Request.Method.GET, url, null,
                new Response.Listener<JSONObject>() {
                    @RequiresApi(api = Build.VERSION_CODES.O)
                    @Override
                    public void onResponse(JSONObject response) {
                        try {
                             res = response.getJSONObject("data").getJSONObject("response");
                            JSONObject con = res.getJSONObject("content");
                            final String article_url = con.getString("webUrl");

                            artUrl.setMovementMethod(LinkMovementMethod.getInstance());
                            artUrl.setOnClickListener(new View.OnClickListener() {
                                @Override
                                public void onClick(View v) {
                                    Intent browser = new Intent(Intent.ACTION_VIEW);
                                    browser.setData(Uri.parse(article_url));
                                    startActivity(browser);
                                }
                            });
                            JSONObject blk = con.getJSONObject("blocks");
                            JSONArray jsonArray1 = blk.getJSONArray("body");
                            JSONObject idx = jsonArray1.getJSONObject(0);
                            String id = idx.getString("bodyHtml");
                            String plain = Jsoup.parse(id).text();
                            LocalDate ld = LocalDate.parse(pub_date.substring(0,10));
                            String month = ld.getMonth().toString();
                            month = month.charAt(0) + month.substring(1,3).toLowerCase();
                            String display_date = ld.getDayOfMonth() + " " + month + " " + ld.getYear();
                            //Log.i("date", String.valueOf(ld.getDayOfMonth()));

                            Picasso.with(getApplicationContext()).load(imageUrl).into(imageView);
                            expandTitle.setText(newsTitle);
                            date.setText(display_date);
                            textViewSec.setText(sec);
                            description.setText(plain);
                            actionBarTitle.setText(newsTitle);
                            actionBarTitle1.setText(newsTitle);

                        } catch (JSONException e) {
                            e.printStackTrace();
                        }
                    }
                }, new Response.ErrorListener() {
            @Override
            public void onErrorResponse(VolleyError error) {
                error.printStackTrace();
            }
        });

        mRequestQueue.add(request);


        if (checkbookmark(id)){
            bookmark_add.setVisibility(View.GONE);
            bookmark_remove.setVisibility(View.VISIBLE);
            actionBarTitle.setVisibility(View.GONE);
            actionBarTitle1.setVisibility(View.VISIBLE);
        }
        else {
            bookmark_add.setVisibility(View.VISIBLE);
            bookmark_remove.setVisibility(View.GONE);
            actionBarTitle.setVisibility(View.VISIBLE);
            actionBarTitle1.setVisibility(View.GONE);
        }
    }

    private void displayData(){

    }

    private void parseJSON(String id){
        String url = "https://hw9-backend-276422.wl.r.appspot.com/detail?art_id=" + id;
        JsonObjectRequest request = new JsonObjectRequest(Request.Method.GET, url, null,
                new Response.Listener<JSONObject>() {
                    @RequiresApi(api = Build.VERSION_CODES.O)
                    @Override
                    public void onResponse(JSONObject response) {
                        try {
                            res = response.getJSONObject("data").getJSONObject("response");
                            dataReceived=true;
                            //Log.i("tag",res.toString());

                        } catch (JSONException e) {
                            e.printStackTrace();
                            //Log.i("err",response.toString());
                        }
                    }
                }, new Response.ErrorListener() {
            @Override
            public void onErrorResponse(VolleyError error) {
                error.printStackTrace();
            }
        });
        mRequestQueue.add(request);
    }

    public boolean checkbookmark(String artId){
        SharedPreferences prefs = getApplicationContext().getSharedPreferences(MyBook,0);
        String article = prefs.getString(artId,"");
        if (article.length() == 0)
            return false;
        else
            return true;
    }

}
