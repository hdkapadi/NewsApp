package com.example.hw9;

import android.app.Dialog;
import android.content.Context;
import android.content.Intent;
import android.content.SharedPreferences;
import android.graphics.Color;
import android.net.Uri;
import android.os.Build;
import android.os.Bundle;
import android.os.Handler;
import android.util.Log;
import android.view.Menu;
import android.view.MenuInflater;
import android.view.MenuItem;
import android.view.View;
import android.widget.AdapterView;
import android.widget.ArrayAdapter;
import android.widget.ImageView;
import android.widget.ProgressBar;
import android.widget.TextView;
import android.widget.Toast;

import androidx.annotation.RequiresApi;
import androidx.appcompat.app.ActionBar;
import androidx.appcompat.app.AlertDialog;
import androidx.appcompat.app.AppCompatActivity;
import androidx.appcompat.widget.SearchView;
import androidx.appcompat.widget.ShareActionProvider;
import androidx.appcompat.widget.Toolbar;
import androidx.core.view.MenuItemCompat;
import androidx.recyclerview.widget.LinearLayoutManager;
import androidx.recyclerview.widget.RecyclerView;
import androidx.swiperefreshlayout.widget.SwipeRefreshLayout;

import com.android.volley.Request;
import com.android.volley.RequestQueue;
import com.android.volley.Response;
import com.android.volley.VolleyError;
import com.android.volley.toolbox.JsonObjectRequest;
import com.android.volley.toolbox.Volley;
import com.squareup.picasso.Picasso;

import org.json.JSONArray;
import org.json.JSONException;
import org.json.JSONObject;

import java.text.ParseException;
import java.text.SimpleDateFormat;
import java.util.ArrayList;
import java.util.Date;
import java.util.concurrent.TimeUnit;

public class SearchActivity extends AppCompatActivity implements ExampleAdapter.OnItemClickListener, ExampleAdapter.OnItemLongClickListener{
    public static final String EXTRA_KEYWORD = "keyword";
    private boolean dataReceived;
    private ExampleAdapter mExampleAdapter;
    private Context mContext;
    private RecyclerView mRecyclerView;
    private ArrayList<ExampleItem> mExampleList;
    private RequestQueue mRequestQueue;
    private ImageView bookmarkImageView;
    private SwipeRefreshLayout mSwipeRefreshLayout;
    private JSONObject res;
    private ProgressBar spinner;
    public String keyword;
    public static final String EXTRA_URL = "imageUrl";
    public static final String EXTRA_CREATOR = "creatorName";
    public static final String EXTRA_LIKES = "likeCount";
    public static final String EXTRA = "sect";
    public static final String ID = "id";
    public static final String DETAIL = "detail_date";
    public static final String EXTRA_WEBURL = "webUrl";
    public final String MyBook = "bookmarks";


    @Override
    protected void onCreate(Bundle savedInstanceState) {
        super.onCreate(savedInstanceState);
        setContentView(R.layout.search);
        Intent intent = getIntent();
        //Log.i("data","-----------");
        keyword = intent.getStringExtra(EXTRA_KEYWORD);

        spinner = (ProgressBar) findViewById(R.id.progressBar1);
        Toolbar toolbar = (Toolbar) findViewById(R.id.toolbar_search);
        mSwipeRefreshLayout = findViewById(R.id.swipe);
        final TextView fetching_text = findViewById(R.id.search_pbar_text);

        setSupportActionBar(toolbar);
        getSupportActionBar().setDisplayHomeAsUpEnabled(true);
        getSupportActionBar().setDisplayShowHomeEnabled(true);
        getSupportActionBar().setTitle("Search Results for "+keyword);

        toolbar.setNavigationOnClickListener(new View.OnClickListener() {
            @Override
            public void onClick(View v) {
                onBackPressed();
            }
        });

        mRecyclerView = findViewById(R.id.recyclerview_search);
        LinearLayoutManager mgr = new LinearLayoutManager(getApplicationContext());
        mRecyclerView.setHasFixedSize(true);
        mRecyclerView.setLayoutManager(mgr);
        bookmarkImageView = findViewById(R.id.imageView);



        mExampleList = new ArrayList<>();

        mRequestQueue = Volley.newRequestQueue(getApplicationContext());
        dataReceived = false;
        parseJSON();
        mRecyclerView.setVisibility(View.GONE);
        final Handler handler = new Handler();
        Runnable runnable = new Runnable() {
            @RequiresApi(api = Build.VERSION_CODES.O)
            @Override
            public void run() {
                if(dataReceived) {
                    try {
                        spinner.setVisibility(View.GONE);
                        fetching_text.setVisibility(View.GONE);
                        mRecyclerView.setVisibility(View.VISIBLE);
                        displayData();
                    } catch (JSONException e) {
                        e.printStackTrace();
                    }
                }
                else {
                    handler.postDelayed(this, 1000);
                }
            }
        };
        handler.post(runnable);

        mSwipeRefreshLayout.setOnRefreshListener(new SwipeRefreshLayout.OnRefreshListener() {
            @RequiresApi(api = Build.VERSION_CODES.O)
            @Override
            public void onRefresh() {
                dataReceived = false;
                parseJSON();
                dataReceived = true;
                Log.i("called","refresh Dta called 1"+dataReceived);
                final Handler handler = new Handler();
                handler.postDelayed(new Runnable() {
                    @Override
                    public void run() {
                        if (dataReceived){
                            Log.i("called","refresh Dta called 2");
                            try {
                                displayData();
                                Log.i("called","refresh Dta called 3");
                            } catch (JSONException e) {
                                e.printStackTrace();
                            }
                        }
                        if(mSwipeRefreshLayout.isRefreshing()) {
                            mSwipeRefreshLayout.setRefreshing(false);
                        }
                    }
                }, 1000);
            }
        });

    }

    public void parseJSON() {
        final SimpleDateFormat sdf = new SimpleDateFormat();
          String url = "https://hw9-backend-276422.wl.r.appspot.com/search?q=" + keyword;
        JsonObjectRequest request = new JsonObjectRequest(Request.Method.GET, url, null,
                new Response.Listener<JSONObject>() {
                    @RequiresApi(api = Build.VERSION_CODES.O)
                    @Override
                    public void onResponse(JSONObject response) {
                        try {
                            res = response.getJSONObject("data").getJSONObject("response");
                            dataReceived=true;
                        } catch (JSONException e) {
                            e.printStackTrace();
                        }
                    }
                }, new Response.ErrorListener() {
            @Override
            public void onErrorResponse(VolleyError error) {
                error.printStackTrace();
            }
        });
        mRequestQueue.add(request);
    }

    @RequiresApi(api = Build.VERSION_CODES.O)
    private void displayData() throws JSONException{

        JSONArray jsonArray = res.getJSONArray("results");
        for (int i = 0; i < jsonArray.length(); i++) {
            String imageUrl="";
            JSONObject hit = jsonArray.getJSONObject(i);
            JSONObject img = hit.getJSONObject("blocks");
            try {
                JSONObject img1 = img.getJSONObject("main");
                JSONArray arr = img1.getJSONArray("elements");

                JSONObject obj = arr.getJSONObject(0);

                JSONArray arr1 = obj.getJSONArray("assets");

                JSONObject obj1 = arr1.getJSONObject(0);
                imageUrl = obj1.getString("file");

            }
            catch (JSONException e){
                imageUrl = "https://assets.guim.co.uk/images/eada8aa27c12fe2d5afa3a89d3fbae0d/fallback-logo.png";
            }

            String art_id = hit.getString("id");
            String web_url = hit.getString("webUrl");
            String title = hit.getString("webTitle");
            String date = hit.getString("webPublicationDate");
            String name = hit.getString("sectionName");

            mExampleList.add(new ExampleItem(imageUrl, title, date, name, art_id,web_url));
        }

        mExampleAdapter = new ExampleAdapter(SearchActivity.this, mExampleList);
        mRecyclerView.setAdapter(mExampleAdapter);
        mExampleAdapter.notifyDataSetChanged();
        mExampleAdapter.setOnItemClickListener(SearchActivity.this);
        mExampleAdapter.setOnItemLongClickListener(SearchActivity.this);

    }

    public void onItemClick(int position) {
        Intent detailIntent = new Intent(SearchActivity.this, DetailActivity.class);
        ExampleItem clickedItem = mExampleList.get(position);

        detailIntent.putExtra(EXTRA_URL, clickedItem.getImageUrl());
        detailIntent.putExtra(EXTRA_CREATOR, clickedItem.getCreator());
        detailIntent.putExtra(EXTRA_LIKES, clickedItem.getLikeCount());
        detailIntent.putExtra(EXTRA,clickedItem.getSection());
        detailIntent.putExtra(ID,clickedItem.getid());
        detailIntent.putExtra(EXTRA_WEBURL,clickedItem.geturl());

        startActivity(detailIntent);
    }

    @Override
    public void onResume() {
        super.onResume();
        if(mExampleAdapter != null)
            mExampleAdapter.notifyDataSetChanged();
    }

    @Override
    public void onItemLongClick(int p) {
        final JSONObject obj = new JSONObject();
        SharedPreferences sharedPreferences = getApplicationContext().getSharedPreferences(MyBook,0);
        final SharedPreferences.Editor editor = sharedPreferences.edit();
        ExampleItem item = mExampleList.get(p);
        final Dialog dialog = new Dialog(SearchActivity.this);
        dialog.setContentView(R.layout.dialog);

        final String articleId = item.getid();
        final String title = item.getCreator();
        String date = item.getLikeCount();
        String section = item.getSection();
        String imageUrl = item.getImageUrl();
        final String web_url = item.geturl();

        try {
            obj.put("imageUrl",imageUrl);
            obj.put("title",title);
            obj.put("date",date);
            obj.put("section",section);
            obj.put("web_url",web_url);
        } catch (JSONException e) {
            e.printStackTrace();
        }
        ImageView imageView = dialog.findViewById(R.id.dialog_image);
        Picasso.with(getApplicationContext()).load(imageUrl).into(imageView);
        TextView textView = dialog.findViewById(R.id.dialog_text);
        textView.setText(item.getCreator());
        ImageView imageView1 = dialog.findViewById(R.id.dialog_twitter);
        imageView1.setImageResource(R.drawable.twitter);
        final ImageView imageView2 = dialog.findViewById(R.id.dialog_bookmark);
        final ImageView imageView3 = dialog.findViewById(R.id.dialog_bookmark1);

        if (sharedPreferences.contains(articleId)){
            imageView2.setVisibility(View.GONE);
            imageView3.setVisibility(View.VISIBLE);
            imageView3.setOnClickListener(new View.OnClickListener() {
                @Override
                public void onClick(View v) {
                    imageView2.setVisibility(View.VISIBLE);
                    imageView3.setVisibility(View.GONE);
                    editor.remove(articleId);
                    editor.apply();
                    Toast.makeText(getApplicationContext(), "\""+title+"\" was removed from bookmarks", Toast.LENGTH_SHORT).show();
                    mExampleAdapter.notifyDataSetChanged();
                }
            });
        }
        else {
            imageView2.setVisibility(View.VISIBLE);
            imageView3.setVisibility(View.GONE);
            imageView2.setOnClickListener(new View.OnClickListener() {
                @Override
                public void onClick(View v) {
                    imageView2.setVisibility(View.GONE);
                    imageView3.setVisibility(View.VISIBLE);
                    editor.putString(articleId,obj.toString());
                    editor.apply();
                    Toast.makeText(getApplicationContext(), "\""+title+"\" was added to bookmarks", Toast.LENGTH_SHORT).show();
                    mExampleAdapter.notifyDataSetChanged();
                }
            });
        }

        //add to bookmark
        imageView2.setOnClickListener(new View.OnClickListener() {
            @Override
            public void onClick(View v) {
                imageView2.setVisibility(View.GONE);
                imageView3.setVisibility(View.VISIBLE);
                editor.putString(articleId,obj.toString());
                editor.apply();
                Toast.makeText(getApplicationContext(), "\""+title+"\" was added to bookmarks", Toast.LENGTH_SHORT).show();
                mExampleAdapter.notifyDataSetChanged();
            }
        });

        //remove from bookmark
        imageView3.setOnClickListener(new View.OnClickListener() {
            @Override
            public void onClick(View v) {
                imageView2.setVisibility(View.VISIBLE);
                imageView3.setVisibility(View.GONE);
                editor.remove(articleId);
                editor.apply();
                Toast.makeText(getApplicationContext(), "\""+title+"\" was removed from bookmarks", Toast.LENGTH_SHORT).show();
                mExampleAdapter.notifyDataSetChanged();
            }
        });

        imageView1.setOnClickListener(new View.OnClickListener() {
            @Override
            public void onClick(View v) {
                String url = "http://www.twitter.com/intent/tweet?url=" +web_url+ "&hashtags=CSCI571NewsSearch";
                Intent i = new Intent(Intent.ACTION_VIEW);
                i.setData(Uri.parse(url));
                startActivity(i);
            }
        });

        dialog.show();
    }
}
